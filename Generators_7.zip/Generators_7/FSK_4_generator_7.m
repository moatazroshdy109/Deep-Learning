% This code I will create different scenarios to accomodate
% the real life situations, the scenarios will contain
% the following, Metropolitan, urban, suburban, rural 
% from P-1546 mode .
% Changed the frequency offest equation units.
% Changed the loss function to calculate the average loss instead of the
% loss being directly calculated from P-1546.
% Changed units of velocity to m/s
% optimized the program to initialize less functions in each loop
% Treated the AWGN problem and changed the AWGN from awgn to noise_awgn
% changed the alogrithm of the up-conversion and the down-conversion
% removed the global normalization
% Added the progress bar
% Added calculated loss array

area_options = ["metro" "smallcity" "suburban" "rural"];
                                % Controls the out of memory errors
                                % cause max no. of examples tried in a
                                % single trial is 52 thousand
R_s = 4800;                     % symbol rate
sps = 8;                        % Samples per symbol
Fs_bb = R_s*sps*sps;            % Sampling frequency baseband
freqSep = R_s/4;                % Frequency deviation
M = 4;                          % Modulation order
num_bps = log2(M);              % Bits per symbol
spb = sps/num_bps;              % Samples per bits
num_samp = 2048;                % Required number of samples per
                                % example
num_bits = num_samp/spb;        % Number of bits
num_sym = num_bits/num_bps;     % number of symbols
size_to_check = num_samp*sps; 
%%%%%%%% New %%%%%%%%%
frequency_start = 30e6;         % Starting frequency in Hz (30 MHz)
frequency_end = 3000e6;         % Ending frequency in Hz (3000 MHz)
frequency_increment = 100e6;    % Increment in frequency in Hz (100 MHz)
frequencies = frequency_start:frequency_increment:frequency_end;
                                % Generate frequency values
SNR = 10:2:30;
num_examples = 15*10; 

%% Constant functions

fskmod_bit = comm.FSKModulator(M,freqSep,R_s,...
    BitInput=true, ...
    SamplesPerSymbol=sps, ...
    ContinuousPhase=false, ...
    SymbolMapping="Gray");

txfilter = comm.RaisedCosineTransmitFilter( ...
    "RolloffFactor",0.2, ...
    'OutputSamplesPerSymbol',sps);

for k = 1:length(area_options)
    %% Constant parameters
    tic;

    area = area_options(k);         % Area type for channel modeling
    progress_bar_message = ['Processing ', convertStringsToChars(area),...
        ' with index ',num2str(k)];
    h = waitbar(0, progress_bar_message);          % Initialize the waitbar
    total_iterations = num_examples*length(frequencies)*length(SNR);

    examples = zeros(1024,num_examples);  
    SNR_values = zeros(1,num_examples*length(frequencies)*length(SNR));
    all_examples = zeros(1024,num_examples*length(frequencies)*length(SNR));
    channel_type = cell(1,num_examples*length(frequencies)*length(SNR));
    index_1 = 1;
    index_2 = 1;
    for i = 1:length(SNR)
        for j = 1:length(frequencies)
            for example = 1:num_examples 
                %% Variable parameters randomly generated every loop
                Fc = frequencies(j) + (example - 1) * (frequency_increment / num_examples);   
                F_acc = (rand * 50) -25;        % Frequency accuarcy ±2.5 PPM
                FrequencyOffset = (Fc * F_acc/1e9);
                                                % Frequency offset of the VCO
                PhaseOffset = rand * 360;       % Phase offset due to freq 
                                                % correction
                samplerateoffset = ((rand * 50) - 25)*1e-3;   
                                                % ranges between ±2.5 PPM
                kI = 1 - (0.0583 + (0.1818 - 0.0583)*rand);
                kQ = 1 - (0.0583 + (0.1818 - 0.0583)*rand);
                phi = -(4 + (12 - 4)*rand);             
       
                %% Function Initialization
                
                 sro = comm.SampleRateOffset(samplerateoffset);
        
                %% Code excution
                Data = randi ([0 1], round(num_bits), 1);
                modSignal_1 = fskmod_bit(Data);
                modSignal_1 = txfilter(modSignal_1);

                rxSig_1 = noise_awgn(modSignal_1, SNR(i));
                rxSig_1 = FIR_BPF_3(rxSig_1);
                rxSig_2 = phase_freq_offset_signal(rxSig_1, ...
                    PhaseOffset, 0, Fs_bb);
                rxSig_2 = applyIQimbalance(rxSig_2, kI, kQ, phi);
                rxSig_2 = sro(rxSig_2);
                rxSig_2 = adjustRxSigSize(rxSig_2, size_to_check);

                rxSig_4 = normalizeComplexArray(rxSig_2);
                examples(:,index_2) = single(rxSig_4(256:1280-1));  
                
                SNR_values (:,index_1) = SNR(i);
                channel_type{index_1}=area;
                index_1 = index_1+1;
                index_2 = index_2+1;

                waitbar(index_1 / total_iterations, h);
                                                % Update the waitbar
                                                
            end
            all_examples(:,(j - 1) * num_examples + 1 : j * num_examples) = examples;
            index_2 = 1;
        end
    end
    %% Saving the data

    examples_IQ = cat(3,real(all_examples), imag(all_examples));
    examples_IQ = permute(examples_IQ,[3,1,2]);
    mod = repelem("4-FSK", i*j*example);
    labels = cat(1,mod,channel_type);
    file_name_2 = ['MFSK-4',convertStringsToChars(area),'.mat'];
    save(file_name_2 ,'examples_IQ','SNR_values','labels');

%%%%%%%% New %%%%%%%%%
    close(h);           % Close the waitbar when the processing is complete

    toc

    % Get a list of all variable names in the workspace
    allVariables = who;
    % Identify variables to clear (all except variable1 and variable2)
    variablesToClear = setdiff(allVariables, {'area_options', 'k', ...
        'R_s','sps','Fs_bb','freqSep','M','num_bps','spb', ...
        'num_samp','num_bits','num_sym', 'num_examples',...
        'size_to_check','fskmod_bit','frequency_start', 'txfilter',...
        'frequency_end','frequency_increment','frequencies','SNR'});
    if ~isempty(variablesToClear)
        % Clear the identified variables
        clear(variablesToClear{:});
    end

end




