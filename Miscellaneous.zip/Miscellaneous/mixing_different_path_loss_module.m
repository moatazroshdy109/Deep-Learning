array_length = 100;  % Replace with the actual length of your array
original_array = rand(1, array_length);  % Replace with the actual array data
beta = 1.5;  % Replace with your desired value for beta
alpha = 0.8;  % Replace with your desired value for alpha
total_iterations = 10;
% Loop through iterations
for iteration = 1:total_iterations
    % Your existing loop code here...

    % Check if the special operation should be performed (20% of the time)
    if rand() <= 0.2
        fprintf('Special operation at iteration %d\n', iteration);

        % Randomly determine the split point
        split_point = randi(array_length - 1);

        % Split the array into two parts
        part1 = original_array(1:split_point);
        part2 = original_array(split_point + 1:end);

        % Calculate the sum of the original array
        original_sum = sum(original_array);

        % Multiply each part by different factors
        part1 = part1 * beta;
        part2 = part2 * (alpha + beta);

        % Combine the two parts to get the modified array
        modified_array = [part1, part2];

        % Verify that the sum of the modified array is the same as the original sum
        modified_sum = sum(modified_array);
        fprintf('Original Sum: %.4f, Modified Sum: %.4f\n', original_sum, modified_sum);

        % Your additional code using modified_array here...
    end
end
