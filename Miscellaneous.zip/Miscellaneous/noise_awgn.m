function noisy_signal = noise_awgn(signal,reqSNR)
% the function measures the input complex signal power and adds awgn with
% the required SNR 
% SNR input in dB

sigPower = sum(abs(signal).^2)/numel(signal);
reqSNR_linear = 10^(reqSNR/10);
noisePower = sigPower/reqSNR_linear;
noise = sqrt(noisePower/2)* complex(randn(size(signal)), ...
                                  randn(size(signal))); 
                                                % from matlab fn(awgn)
noisy_signal = signal + noise;

end