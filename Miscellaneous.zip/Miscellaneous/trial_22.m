% The length of input bits is N. The length of the output bits must also be
% N
clear all
N = 4096*1;
x = randi([0,3],N,1);
sym = 2*x-3;                    % integer input

% Raised Cosine Filter
sampsPerSym = 4;                % Upsampling factor
% Design raised cosine filter with given order in symbols. Apply gain to
% the unit energy filter to obtain max amplitude of 1.
rctFilt = comm.RaisedCosineTransmitFilter(...
    'Shape', 'Normal', ...
    'RolloffFactor', 0.2, ...
    'OutputSamplesPerSymbol', sampsPerSym, ...
    'FilterSpanInSymbols', 60, ...
    'Gain', 1.9493);
c4fm_init = rctFilt(sym);

shape2 = 'Inverse-sinc Lowpass';
d2 = fdesign.interpolator(2, shape2);
intrpltr = design(d2, 'SystemObject', true);
c4fm_init = intrpltr(c4fm_init);

% Baseband Frequency Modulator
Fs = 4800*2;

freqdev = 600;
int_x = cumsum(c4fm_init)/Fs;
c4fm_output = exp(1i*2*pi*freqdev*int_x);
y = c4fm_output(1:N); % Ideal case, SNR = infinity
y1 = awgn(y,10);       % SNR = 3 dB
y2 = awgn(y,-3);      % SNR = -3 dB

%%
figure(2)
% subplot(3,1,1)
% carrierinstampl=abs(c4fm_output);
% carrierinstphase=unwrap(angle(c4fm_output));
% mc=(carrierinstampl);
% nc=(carrierinstphase);
% polarplot(nc,mc,'*');
% title ('Vector Representation of Modulated Signal');

% subplot(3,1,2)
[SIGNAL_2,fVals_2]=freqDomainView(c4fm_output,Fs,'double');
plot(fVals_2,abs(SIGNAL_2)); 
title('X[f] DSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

% subplot(3,1,3)
% t = (0:length(c4fm_output)-1) / Fs;  % Time vector
% plot(t,real(c4fm_output))
% title('x(t) Modulated Signal');
% % xlim([0 0.01])