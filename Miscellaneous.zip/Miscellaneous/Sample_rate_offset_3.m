% Gen AWGN QPSK data
I = sqrt(2)/2 * (2*randi(2,1000,1) - 3) + 1e-1*randn(1000,1);
Q = sqrt(2)/2 * (2*randi(2,1000,1) - 3) + 1e-1*randn(1000,1);
% apply IQ offest
Fc=50e6;
R_s = 4800;                     % symbol rate
sps = 8;                        % Samples per symbol
Fs_bb = R_s*sps;
samplerateoffset = rand * 5 -2.5;

signal = I + 1i * Q;
sro = comm.SampleRateOffset(samplerateoffset);
complexOutput = sro(signal);

I_o = real(complexOutput);
Q_o = imag(complexOutput);
figure(1)
scatter(I,Q); hold on;
scatter(I_o,Q_o); title('QPSK Waveform');
xlabel('In-phase'); ylabel('Quadriture');
legend('No IQ Offset','IQ Offset'); xlim([-1.5 1.5]); ylim([-1.5 1.5]);
hold off

