%% Create a sample signal
Fc_1 = 50;
Fc_2 = 120;
Fs_bb = Fc_2 * 20;
rand_object = RandStream('mt19937ar','Seed',5489); 
t = 0:1/Fs_bb:1; % Time vector
signal = sin(2*pi*Fc_1*t) + 0.5i*sin(2*pi*Fc_2*t);

%% Up-conversion
InterpolationFactor_1 = 652;    % Interpolation of the DUC
F_if = 10.7e6;                  % Intermediate frequency
Fs_if = Fs_bb*InterpolationFactor_1;
                                % Sampling frequency of IF

upConv_1 = dsp.DigitalUpConverter( ...
    'InterpolationFactor',InterpolationFactor_1,...
    'SampleRate',Fs_bb,...
    'Bandwidth',2e3,...
    'PassbandRipple',0.28, ...
    'CenterFrequency',F_if, ...
    'OutputDataType','Same as input');

signal_real = upConv_1(real(signal));
signal_2_imag = upConv_1(imag(signal));
signal = signal_real + 1i * signal_2_imag;

%% Add white Gaussian noise with a specified SNR
% method 1
SNR = -20; % in dB
noisySignal = noise_awgn(signal, SNR);
% method 2
% sigPower_linear = sum(abs(signal).^2)/numel(signal);
% sigPower = pow2db(sigPower_linear);
% noisySignal = awgn(signal,SNR,sigPower,'dB');

%% Normalize the signal

norm_signal = normalizeComplexArray(signal);
norm_noisy_signal = normalizeComplexArray(noisySignal);

%% Plot the original and noisy signals

% figure(1);
% subplot(2,1,1)
% plot(t, signal, 'b', t, noisySignal, 'r');
% legend('Original Signal', 'Noisy Signal');
% xlabel('Time');
% ylabel('Amplitude');
% title('Original and Noisy Signals');
% 
% subplot(2,1,2)
% [SIGNAL_1,fVals_1]=freqDomainView(signal,Fs_if,'double');
% [SIGNAL_2,fVals_2]=freqDomainView(noisySignal,Fs_if,'double');
% plot(fVals_1,abs(SIGNAL_1),'b',fVals_2,abs(SIGNAL_2),'r'); 
% title('Original and Noisy Signals'); xlabel('frequencies (f)'); ylabel('|X(f)|');
% legend('Original Signal', 'Noisy Signal');

figure(2);
subplot(2,1,1)
plot(t, norm_signal, 'b', t, norm_noisy_signal, 'r');
legend('Original Signal', 'Noisy Signal');
xlabel('Time');
ylabel('Amplitude');
title('Original and Noisy Signals Normalized');

subplot(2,1,2)
[SIGNAL_1,fVals_1]=freqDomainView(signal,Fs_if,'double');
[SIGNAL_2,fVals_2]=freqDomainView(noisySignal,Fs_if,'double');
plot(fVals_1,abs(SIGNAL_1),'b',fVals_2,abs(SIGNAL_2),'r'); 
legend('Original Signal', 'Noisy Signal');
title('Original and Noisy Signals Normalized'); 
xlabel('frequencies (f)'); ylabel('|X(f)|');