% %% reading a song file
% audiofilereader = dsp.AudioFileReader( ...
%     "guitartune.wav", ...
%     SamplesPerFrame=44100);
% 
% %% FM modulator and demodulator objects
% 
% fmbMod = comm.FMBroadcastModulator( ...
%     'AudioSampleRate',audiofilereader.SampleRate, ...
%     'SampleRate',240e3);
% fmbDemod = comm.FMBroadcastDemodulator( ...
%     'AudioSampleRate',audiofilereader.SampleRate, ...
%     'SampleRate',240e3,'PlaySound',true);
% 
% %% processing
% 
% while ~isDone(audiofilereader)      % Read the audio data in frames of 
%                                     % length 4410.
%     audioData = audiofilereader();      
%     modData = fmbMod(audioData);    %  apply FM broadcast modulation
%     demodData = fmbDemod(modData);  % Demodulate and play signal
% end



%% reading a song file
audiofilereader = dsp.AudioFileReader( ...
    "guitartune.wav", ...
    SamplesPerFrame=44100);
x = audiofilereader();

%% Spectrum analyzer visualization

saFM = spectrumAnalyzer( ...
    SampleRate=152e3, ...
    Title="FM Broadcast Signal");
saAudio = spectrumAnalyzer( ...
    SampleRate=44100, ...
    ShowLegend=true, ...
    Title="Audio Signal", ...
    ChannelNames=["Input signal" "Demodulated signal"]);

%% Modulator and demodulator objects

fmbMod = comm.FMBroadcastModulator( ...
    AudioSampleRate=audiofilereader.SampleRate, ...
    SampleRate=200e3);
fmbDemod = comm.FMBroadcastDemodulator(fmbMod);

%% processing and visualization

y = fmbMod(x);
saFM(y)

%% continue processing

z = fmbDemod(y);
saAudio([x z])

%% Visualization 1
SampleRate=44100;
figure(1)
[SIGNAL_1,fVals_2]=freqDomainView(x,SampleRate,'double');
plot(fVals_2,abs(SIGNAL_1)); 
title('X[f] Voice Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');