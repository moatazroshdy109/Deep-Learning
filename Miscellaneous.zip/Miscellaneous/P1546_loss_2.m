function PL = P1546_loss_2(Fc, distance, envType, q_value)
    % Generates the loss from the p.1546 loss curves
    % make sure the units are compensated
    % Fc ... is in Mhz
    % Distance is Km
    % envType - 'metro','smallcity','suburban' or 'rural'

    t = 1 + (50 - 1)*rand;  % ranges between 1% and 50%
    path_c = 'Land';
    pathinfo = 0; 
%% P-1546 Curves
    envType=lower(envType);
    switch envType
        case 'metro'
            heff =  25 + (55 - 25)*rand; % ranges from 0m to 15m
            ha = heff;
            h2 = 1.5 + (3 -1.5)*rand;
            R2 = 15 + (45 - 15)*rand;
            R1 = R2 + (45 - R2)*rand;
            [~, PL] = P1546FieldStrMixed(Fc, t, heff, ...
            h2,R2,'Dense Urban', distance, path_c, pathinfo, ...
            'ha',ha, 'R1', R1, 'q', q_value);

        case 'smallcity'
            heff =  19 + (28 - 25)*rand; % ranges from 0m to 15m
            ha = heff;
            h2 = 1.5 + (3 -1.5)*rand;
            R2 = 9 + (18 - 9)*rand;
            R1 = R2 + (18 - R2)*rand;
            [~, PL] = P1546FieldStrMixed(Fc, t, heff, ...
            h2,R2,'Urban', distance, path_c, pathinfo, ...
            'ha',ha, 'R1', R1, 'q', q_value);
    
        case 'suburban'
            heff =  12 + (15 - 12)*rand; % ranges from 12 m to 15m
            ha = heff;
            h2 = 1.5 + (3 -1.5)*rand;
            R2 = 7 + (10 - 7)*rand;
            R1 = R2 + (10 - R2)*rand;
            [~, PL] = P1546FieldStrMixed(Fc, t, heff, ...
            h2,R2,'Urban', distance, path_c, pathinfo, ...
            'ha',ha, 'R1', R1, 'q', q_value);

        case 'rural'
            heff =  12 + (15 - 12)*rand; % ranges from 12 m to 15 m
            ha = heff;
            h2 = 1.5 + (3 -1.5)*rand;
            R2 = 5 + (10 - 5)*rand;
            R1 = R2 + (10 - R2)*rand;
            [~, PL] = P1546FieldStrMixed(Fc, t, heff, ...
            h2,R2,'Rural', distance, path_c, pathinfo, ...
            'ha',ha, 'R1', R1, 'q', q_value);     

        otherwise , error('Invalid model selection');

    end

