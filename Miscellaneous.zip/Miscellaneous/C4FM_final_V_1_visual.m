%% Notes before running the code

% If the up conversion to the RF is applied the sampling frequency
% of the channel model should include the interpolation factor of the up
% conversion to the RF.

% 21/9/2023, we have include so far in the code, the up conversion to the
% intermediate frequency and the RF, channel model of VHF and UHF but it
% doesn't include the path loss function created by ITU standard. Also the
% code has phase, frequency, and sample rate offsets as an implementation
% of the hardware impairments.

% The code generates a 1000 examples for each SNR level included, each
% example has 1024 samples in accordance with famous RML2018 dataset by
% timothy O;shea. they are saved in a .mat file as concatenated IQ samples 


%% Initialization
clc
close all
clear variables
%% Loading Parameters
tic;

% SNR = -20:2:20;
SNR = 20:2:20;
num_examples = 1;

examples = zeros(1024,num_examples*length(SNR));  
SNR_values = zeros(1,num_examples*length(SNR));

index = 1;
for i = 1:length(SNR)
    for k = 1:num_examples   % 1000 example, each example contains 1024 sample
        fprintf('Iteration no.: %.0f \n', index);
        % Carrier frequency selection
        % frequency ranges according to DMR standard
        frequencyRanges = {
            [30e6, 50e6]
            [136e6, 174e6]     
            [380e6, 520e6]    
            [806e6, 870e6]    
        };

        % Choose a random range index
        numRanges = numel(frequencyRanges);
        randomRangeIndex = randi(numRanges);
        
        % Get the selected frequency range
        selectedRange = frequencyRanges{randomRangeIndex};
        
        % Generate a random frequency within the selected range
        Fc = selectedRange(1) + (selectedRange(2) - selectedRange(1)) * rand();
% %         fprintf('Random Frequency: %.2f MHz\n', Fc / 1e6);         
                                    % Convert to MHz for display
        
        Fs = 25e6;                  % Sampling frequency according NI-USRP 2030
        freqdev = 600;              % Frequency deviation for modulation
                                    % +3 --> +1,944 kHz, +1 --> 0.648 kHz 
        F_if = 10.7e6;              % Intermediate frequency  % needs to be checked
        R_s = 4800;                 % symbol rate
        time_win = 0.00004096;      % time window of captured signal in
                                    % seconds with a total of 0.08 = 80 ms 
                                    % or in otherwords, it is the 1024 
                                    % which is number of samples per 
                                    % example = 40 µs

        M = 4;                      % Modulation order
        num_bps = log2(M);          % number of bits per symbol according 
                                    % to the modulation order   
        sps = 8;                    % Samples per symbol
                
        spb = sps/num_bps;          % meaning that each symbol has 8 samples
                                    % samples per bits %% change to be originated from symbols
        
        num_samp = time_win*Fs;     % number of samples 
        num_bits = num_samp/spb;    % number of bits

        num_sym = num_bits/num_bps; % number of symbols cause the modulation order
                                    % is 4-FSK     
        Ts = sps/Fs;                % Symbol time period

        F_acc = rand * 5 -2.5;      % Frequency accuarcy ±2.5 PPM
        FrequencyOffset = (Fc * F_acc)/10e6;
                                    % Frequency offset of the VCO
        PhaseOffset = rand * 360; % Phase offset due to freq correction
        
        samplerateoffset = rand * 5 -2.5;   
                                    % ranges between ±2.5 PPM

        InterpolationFactor_1 = 2;
        InterpolationFactor_2 = round(((Fc*5.5)/Fs)/InterpolationFactor_1);
        

%% Data and modulation

                                    % I will need to do a gray symbol
                                    % mapping later from bits, but so far
                                    % no need, I will just generate random
                                    % symbols
    
    
        unsig_symbols = randi([0,3],num_sym,1);

        qpsk_symbols = 2*unsig_symbols-3;                    % integer input
        
        add_interpolation = num_samp/length(qpsk_symbols); 
                            % this factor is used to make the data reach
                            % the indicated samples per symbols
        qpsk_symbols = repelem(qpsk_symbols,add_interpolation);

        rctFilt = comm.RaisedCosineTransmitFilter(...
            'Shape', 'Normal', ...
            'RolloffFactor', 0.2, ...
            'OutputSamplesPerSymbol', sps, ...
            'FilterSpanInSymbols', 60, ...
            'Gain', 1.9493);
        c4fm_init = rctFilt(qpsk_symbols);
        
        % Design interpolator
        shape2 = 'Inverse-sinc Lowpass';
        d2 = fdesign.interpolator(InterpolationFactor_1, shape2);
        intrpltr = design(d2, 'SystemObject', true);
        c4fm_init = intrpltr(c4fm_init);
        
        % Baseband Frequency Modulator
        int_x = cumsum(c4fm_init)/Fs;
        c4fm_output = exp(1i*2*pi*freqdev*int_x);

        figure(1)
        subplot(2, 1, 1);
        t = (0:length(c4fm_output)-1) / Fs;  % Time vector
        plot(t,real(c4fm_output))
        
        subplot(2, 1, 2);
        ModSignal = fft(c4fm_output);
        ns = length(c4fm_output);
        f = (0:ns-1) * Fs / ns;
        plot(f, abs(ModSignal));
        title('C4FM modulation (Frequency Domain)');
        xlabel('Frequency (Hz)');
        ylabel('Magnitude');
        grid;

        figure(2)
        scatter(real(c4fm_output),imag(c4fm_output))

        %% Up-Conversion
        
        upConv_1 = dsp.DigitalUpConverter('InterpolationFactor',InterpolationFactor_1,...
        'SampleRate',Fs,...
        'Bandwidth',12.5e3,...
        'PassbandRipple',0.28, ...
        'CenterFrequency',F_if);
        
        modSignal_1 = upConv_1(c4fm_output);

        modSignal_1 = FIR_filter_trial_4_LPF(modSignal_1);

        figure(3)
        subplot(2, 1, 1);
        t = (0:length(modSignal_1)-1) / Fs;  % Time vector
        plot(t,real(modSignal_1))
        
        subplot(2, 1, 2);
        ModSignal = fft(modSignal_1);
        ModSignal = fftshift(ModSignal);
        ns = length(modSignal_1);
        f = (0:ns-1) * Fs / ns;
        plot(f, abs(ModSignal));
        title('C4FM Intermediate frequency (Frequency Domain)');
        xlabel('Frequency (Hz)');
        ylabel('Magnitude');
        grid;


        
%         upConv_2 = dsp.DigitalUpConverter('InterpolationFactor',InterpolationFactor_2,...
%         'SampleRate',Fs,...
%         'Bandwidth',12.5e3,...
%         'PassbandRipple',0.28, ...
%         'CenterFrequency',Fc ...
%         );
%         
%         modSignal = upConv_2(modSignal);
        
        %% Square root raised cosine
%         SRRC = comm.RaisedCosineTransmitFilter("Shape", "Square root", ...
%             "FilterSpanInSymbols", 1, ...
%             "RolloffFactor",0.2, ...
%             "Gain",1, ...
%             "OutputSamplesPerSymbol",8);
%         
%         modSignal = SRRC(modSignal);
        
        Decimation_factor = InterpolationFactor_1 * 2 * rctFilt.OutputSamplesPerSymbol;
                                % the interpolation factor was used 2 times
                                % the first time in the implementation of
                                % the modulation and the second time in the
                                % up conversion part.
        
        %% Channel modeling
        distance = (0.1 + (3-0.1) * rand)*1e3;
        wavelength = 3e8/Fc;     % with frequency ranges from 400 MHz to 470 MHz
                                 % 136 MHz to 174 MHz, 410 MHz to 470 MHz,
                                 % 900 MHz to 930 MHz
        
        max_velocity = rand * 60;       % K/hr
        fd = max_velocity/wavelength;
                                 % Maximum Doppler Shift in Hz
        
        doppler_spectrum = doppler('Jakes');
        
        ricianchan = comm.RicianChannel(...
                            'SampleRate',Fs * rctFilt.OutputSamplesPerSymbol, ...    % careful incase you use a higher up conversion
                            'NormalizePathGains',true, ...
                            'DirectPathInitialPhase',0,...
                            'MaximumDopplerShift',fd,...
                            'DopplerSpectrum',doppler_spectrum,...
                            'RandomStream','mt19937ar with seed', ...
                            'Seed',73, ...
                            'PathGainsOutputPort',false);


        % Define the area options
        area_options = {'Rural', 'Urban', 'Dense Urban'};
        
        % Choose an area from the options
        area = area_options{randi(length(area_options))};
                
        % Define K-factor ranges for different areas
        if strcmp(area, 'Rural')
        
            mean_value_1 = 3;
            std_deviation_1 = 1;
            KFactor = mean_value_1 + std_deviation_1 * randn(1);
        elseif strcmp(area, 'Urban')
        
            mean_value_1 = 2.4;
            std_deviation_1 = 1;
            KFactor = mean_value_1 + std_deviation_1 * randn(1);
        
        elseif strcmp(area, 'Dense Urban')
        
            mean_value_1 = 1.6;
            std_deviation_1 = 1;
            KFactor = mean_value_1 + std_deviation_1 * randn(1);
        
        end
                    
        KFactorLin = 10.^(KFactor/10); % Linear units
        ricianchan.KFactor = KFactorLin;

        directpathdoppler = fd*rand;
        ricianchan.DirectPathDopplerShift = directpathdoppler;



        rayleighchan = comm.RayleighChannel( ...
            "NormalizePathGains",true, ...
            'SampleRate',          Fs * rctFilt.OutputSamplesPerSymbol, ...    % careful incase you use a higher up conversion
            'MaximumDopplerShift', fd, ...
            'DopplerSpectrum',     doppler_spectrum, ...
            'RandomStream',        'mt19937ar with seed', ...
            'Seed',                99, ...
            'PathGainsOutputPort', false);
        
        awgnChan = comm.AWGNChannel('NoiseMethod', ...
                                   'Signal to noise ratio (SNR)', ...
                                   'SNR',0);
        
        path1delay = 0.05 + (10-0.05)*rand; % resembling a distance of 3 km
        path2delay = 0.1 + (10-0.1)*rand;   % this is the maximum tolerance
        path3delay = 0.15 + (10-0.1)*rand;  % allowed for the Tetra
        path4delay = 0.2 + (10-0.1)*rand;  
        
        path1gain = -15 + (3-(-15))*rand; 
        path2gain = -15 + (3-(-15))*rand; 
        path3gain = -15 + (3-(-15))*rand; 
        path4gain = -15 + (3-(-15))*rand; 
        
        
        rayleighchan.PathDelays = [path1delay path2delay path3delay path4delay]*1e-6;
        rayleighchan.AveragePathGains = [path1gain path2gain path3gain path4gain];

        ricianchan.PathDelays = [path1delay path2delay path3delay path4delay]*1e-6;
        ricianchan.AveragePathGains = [path1gain path2gain path3gain path4gain];

%         fadedSig = ricianchannel(modSignal);  % applying rician channel
        fadedSig = rayleighchan(modSignal_1);
    
        loss = fspl(distance, wavelength);
        pl_sig = db2pow((-loss+SNR(i))/2)*fadedSig;  % will be changed % the ranges from ITU is between 210 and 280, which is too low
                                                   % free space
        
        
        rxSig_1 = awgn(pl_sig,SNR(i),'measured');


        figure(4)
        subplot(2, 1, 1);
        t = (0:length(rxSig_1)-1) / Fs;  % Time vector
        plot(t,real(rxSig_1))
        
        subplot(2, 1, 2);
        ModSignal = fft(rxSig_1);
        ModSignal = fftshift(ModSignal);
        ns = length(rxSig_1);
        f = (0:ns-1) * Fs / ns;
        plot(f, abs(ModSignal));
        title('C4FM modulation AWGN and Faded (Frequency Domain)');
        xlabel('Frequency (Hz)');
        ylabel('Magnitude');
        grid;

%         downConv_1 = dsp.DigitalDownConverter('DecimationFactor',InterpolationFactor_2,...
%         'SampleRate',Fs*InterpolationFactor_2,...
%         'Bandwidth',12.5e3,...
%         'PassbandRipple',0.28, ...
%         'CenterFrequency',Fc);
%         
%         rxSig = downConv_1(rxSig);
        
        pfo = comm.PhaseFrequencyOffset(PhaseOffset=PhaseOffset, ...
            FrequencyOffset=FrequencyOffset,SampleRate=Fs * rctFilt.OutputSamplesPerSymbol);

        rxSig_2 = pfo(rxSig_1);

        sro = comm.SampleRateOffset(samplerateoffset);
        rxSig_2 = sro(rxSig_2);

        % Define your variable
        size_to_check = num_samp*InterpolationFactor_1 * 2 * rctFilt.OutputSamplesPerSymbol;  % 32768 is actual variable value
        
        % Check if the variable is equal to size_to_check
        
        if length(rxSig_2) > size_to_check
            % If it's larger, decrease it to size_to_check
            num_over_size = length(rxSig_2) - size_to_check ;
            rxSig_2 = rxSig_2(1:size_to_check);
            fprintf('It was larger \n');
        
        elseif length(rxSig_2) < size_to_check 
            % If it's less, increase complex zero elements at the beginning
            % to match the size of size_to_check
            lastElement = rxSig_2(end);
            numDuplicates = size_to_check - length(rxSig_2);
            duplicatedElements = repmat(lastElement, numDuplicates, 1);
            rxSig_2 = [rxSig_2; duplicatedElements];
            fprintf('It was samller \n');
        
        end

        rxSig_3 = FIR_filter_trial_5_LPF(rxSig_2);
       
        figure(5)
        subplot(2, 1, 1);
        t = (0:length(rxSig_3)-1) / Fs;  % Time vector
        plot(t,real(rxSig_3))
        
        subplot(2, 1, 2);
        ModSignal = fft(rxSig_3);
        ModSignal = fftshift(ModSignal);
        ns = length(rxSig_3);
        f = (0:ns-1) * Fs / ns;
        plot(f, abs(ModSignal));
        title('C4FM modulation Hardware impairments (Frequency Domain)');
        xlabel('Frequency (Hz)');
        ylabel('Magnitude');
        grid;

        downConv_2 = dsp.DigitalDownConverter('DecimationFactor',Decimation_factor,...
        'SampleRate',Fs,...
        'Bandwidth',12.5e3,...
        'PassbandRipple',0.28, ...
        'CenterFrequency',F_if);
        
        rxSig_4 = downConv_2(rxSig_3);
        
        figure(6)
        subplot(2, 1, 1);
        t = (0:length(rxSig_4)-1) / Fs;  % Time vector
        plot(t,real(rxSig_4))
        
        subplot(2, 1, 2);
        ModSignal = fft(rxSig_4);
        ns = length(rxSig_4);
        f = (0:ns-1) * Fs / ns;
        plot(f, abs(ModSignal));
        title('C4FM modulation received (Frequency Domain)');
        xlabel('Frequency (Hz)');
        ylabel('Magnitude');
        grid;
        % Rx_filter after the signal reception with bandwidth of 25 kHz
        % you can check the function for further details
        rxSig_5 = FIR_filter_trial_3(rxSig_4);

        examples(:,index) = single(rxSig_5);  % checked number of decimal points
        SNR_values (:,index) = SNR(i);

        release(rayleighchan); 
        index = index+1;
    end
end

examples_IQ = cat(3,real(examples), imag(examples));
examples_IQ = permute(examples_IQ,[3,1,2]);


mod = repelem("4-FSK", i*k);
channel_type = repelem("rayleigh", i*k);

labels = cat(1,mod,channel_type);
file_name = 'DMR_4_FSK.mat';
save(file_name ,'examples_IQ','SNR_values','labels');
%% Profiling
toc;


