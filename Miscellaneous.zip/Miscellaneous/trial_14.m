Fc = selectRandomFrequency_1();   % carrier frequency
distance_0 = (0.1 + (3-0.1) * rand)*1e3;
c = physconst('LightSpeed');
lambda = c /Fc;
area = "metro";             % Area type for channel modeling
loss = P1546_loss(Fc/1e6,distance_0/1e3,area)
% Number of iterations
loss_values = zeros(num_iterations,1);
c = physconst('LightSpeed');
factors_lambda = -10:10;

distance_1 = distance_0 - 10 * lambda;
for i = 1:20

    lambda = c /Fc;
    distance_2 = distance_1 + i * lambda;
    loss_values(i) = P1546_loss(Fc/1e6,distance_2/1e3,area);

end
average_loss = mean(loss_values)
