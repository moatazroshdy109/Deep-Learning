% M = 16;                    % Modulation order
% offset = 50;               % Parts per million
% data = (0:M-1)';           % Input signal
% refconst = qammod(data,M); % Reference constellation points
% 
% sro = comm.SampleRateOffset(offset);
% constdiagram = comm.ConstellationDiagram( ...
%     'ReferenceConstellation',refconst, ...
%     'XLimits',[-5 5], ...
%     'YLimits',[-5 5], ...
%     'Title','Signal with Offset Sample Rate');
% 
% modData = qammod(repmat(data,100,1),M);
% impairedData = step(sro,modData);
% 
% % impairedData = sro(modData);
% constdiagram(impairedData)

%% Example_2
  %   Introduce sample rate offset to a rectangular 16-QAM signal

  M = 16; % Modulation order
  data = (0:M-1)';
  sro = comm.SampleRateOffset(50); % 50 parts per million
  % Modulate data
  modData = qammod(repmat(data,100,1), M);
  scatterplot(modData);
  title(' Original Constellation');xlim([-5 5]);ylim([-5 5])
  % Introduce sample rate offset
  impairedData = sro(modData);
  impairedData(1) = [];
  scatterplot(impairedData);
  title('Constellation after sample rate offset');xlim([-5 5]);ylim([-5 5])