%% new
R_s = 4800;                     % symbol rate
sps = 8;                        % Samples per symbol
Fs_bb = R_s*sps;                % Sampling frequency baseband
Fs_if = Fs_bb*InterpolationFactor_1;

path1delay = 0.05 + (10 - 0.05) * rand;  
path2delay = 0.1 + (10 - 0.1) * rand;   
path3delay = 0.15 + (10 - 0.1) * rand;  
path4delay = 0.2 + (10 - 0.1) * rand;  
PathDelays = [path1delay, path2delay, path3delay, path4delay] * 1e-6;

path1gain = -15 + (3 - (-15)) * rand; 
path2gain = -15 + (3 - (-15)) * rand; 
path3gain = -15 + (3 - (-15)) * rand; 
path4gain = -15 + (3 - (-15)) * rand;
AveragePathGains = [path1gain, path2gain, path3gain, path4gain];

Fc = 3e9;
wavelength = 3e8/Fc;            % Wavelength
max_velocity = 60 * (1000/3600);
                                % Maximum velocity
fd = max_velocity/wavelength;
doppler_spectrum = doppler('Jakes');

%% old
fs = 3.84e6;                                  % Sample rate in Hz
pathDelays = [0 200 800 1200 2300 3700]*1e-9; % in seconds
avgPathGains = [0 -0.9 -4.9 -8 -7.8 -23.9];   % dB
kfact = 10;                                   % Rician K-factor
fD = 50;                                      % Max Doppler shift in Hz
ricianChan = comm.RicianChannel('SampleRate',Fs_if, ...
    'PathDelays',PathDelays, ...
    'AveragePathGains',AveragePathGains, ...
    'KFactor',kfact, ...
    'DopplerSpectrum',doppler_spectrum,...
    'MaximumDopplerShift',fd, ...
    'ChannelFiltering',false, ...             % a necessary condition for 
    ...                                       % visualization purposes
    'Visualization','Impulse and frequency responses');
ricianChan();
