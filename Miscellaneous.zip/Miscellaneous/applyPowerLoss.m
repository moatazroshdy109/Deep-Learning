function processed_signal = applyPowerLoss(signal, loss_1, loss_2)
    % applyPowerLoss - Apply power losses to a signal.
    %
    %   processed_signal = applyPowerLoss(signal, loss_1, loss_2) applies
    %   power losses to the input signal based on the specified conditions.
    %
    %   Inputs:
    %       signal - Input signal to which losses are applied.
    %       loss_1 - First loss value in dB.
    %       loss_2 - Second loss value in dB.
    %
    %   Output:
    %       processed_signal - Signal after applying power losses.
    %
    %   Loss Combination Logic:
    %   - 40% of the time, both losses are combined randomly.
    %   - Otherwise, one of the losses is applied randomly.
    %
    %   Example:
    %       signal = randn(1, 1000);  % Example signal
    %       loss_1 = 3;               % Example loss in dB
    %       loss_2 = 5;               % Example loss in dB
    %       result = applyPowerLoss(signal, loss_1, loss_2);

    if abs(loss_1 - loss_2) > 20
        % Adjust the larger one to have a difference of 20 dB
        if loss_1 > loss_2
            loss_1 = loss_2 + 20;
        else
            loss_2 = loss_1 + 20;
        end
    end
    % Randomly choose whether to add both losses (40% of the time)
    if rand() <= 0.4
        % Randomly determine the split point
        split_point = randi(length(signal) - 1);
        
        % Split the array into two parts
        part1 = signal(1:split_point);
        part2 = signal(split_point + 1:end);

        % Multiply each part by different factors
        part1 = part1 * db2pow(-loss_1);
        part2 = part2 * db2pow(-loss_2);

        processed_signal = [part1; part2];    
    else
        processed_signal = signal * db2pow(-loss_1);
    end
end
