% figure(4)
% % subplot(2,1,1)
[SIGNAL_4,fVals_1]=freqDomainView(modSignal_3,Fs_if,'single');
% plot(fVals_1,abs(SIGNAL_4)); %sample values on x-axis
% title('X[f] SSM AWGN and Channel Zoomed'); xlabel('frequencies (f)'); ylabel('|X(f)|');
% xlim([1.067e7 1.073e7]);

% sigPower = sum(abs(sig(:)).^2)/numel(sig)
% Create an example input array

inputArray = abs(SIGNAL_4);
sigPower_1 = sum(abs(SIGNAL_4).^2)/numel(SIGNAL_4);

% Set a threshold
threshold = max(inputArray)*0.5;

% Extract elements exceeding the threshold
exceedingElements = inputArray(inputArray > threshold);
sigPower_2 = sum(abs(exceedingElements).^2)/numel(exceedingElements);

% % Display the results
% disp('Original Array:');
% disp(inputArray);

% disp('Elements Exceeding the Threshold:');
% disp(exceedingElements);
% subplot(2,1,2)
% % [SIGNAL_4,fVals_1]=freqDomainView(modSignal_3,Fs_if,'single');
% fVals_2 = 1:length(exceedingElements);
% stem(fVals_2,exceedingElements); %sample values on x-axis
% title('X[f] SSM AWGN and Channel Zoomed'); xlabel('frequencies (f)'); ylabel('|X(f)|');
% % xlim([1.067e7 1.073e7]);