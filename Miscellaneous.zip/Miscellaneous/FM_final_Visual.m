%% Notes before running the code

% If the up conversion to the RF is applied the sampling frequency
% of the channel model should include the interpolation factor of the up
% conversion to the RF.

% 21/9/2023, we have include so far in the code, the up conversion to the
% intermediate frequency and the RF, channel model of VHF and UHF but it
% doesn't include the path loss function created by ITU standard. Also the
% code has phase, frequency, and sample rate offsets as an implementation
% of the hardware impairments.

% The code generates a 1000 examples for each SNR level included, each
% example has 1024 samples in accordance with famous RML2018 dataset by
% timothy O;shea. they are saved in a .mat file as concatenated IQ samples 


%% Initialization
clc
close all
clear variables
%% Loading Parameters
tic;

% SNR = -20:2:20;
SNR = 20:2:20;
num_examples = 1;

examples = zeros(1024,num_examples*length(SNR));  
SNR_values = zeros(1,num_examples*length(SNR));

index = 1;
for i = 1:length(SNR)
    for k = 1:num_examples   % 1000 example, each example contains 1024 sample
        fprintf('Iteration no.: %.0f \n', index);
        % Carrier frequency selection
        % frequency ranges according to DMR standard
        frequencyRanges = {
            [148.5e3, 283.5e3]
            [526.5e3, 1606.5e3]
            [3.2e6, 3.4e6]
            [3.95e6, 4e6]
            [4.75e6, 4.995e6]
            [5.005e6, 5.06e6]
            [5.9e6, 6.2e6]
            [7.2e6, 7.45e6]
            [9.4e6, 9.9e6]
            [11.6e6, 12.1e6]
            [13.57e6, 13.87e6]
            [15.1e6, 15.8e6]
            [17.48e6, 17.9e6]
            [18.9e6, 19.02e6]
            [21.45e6, 21.85e6]
            [25.67e6, 26.1e6]
            };

        % Choose a random range index
        numRanges = numel(frequencyRanges);
        randomRangeIndex = randi(numRanges);
        
        % Get the selected frequency range
        selectedRange = frequencyRanges{randomRangeIndex};
        
        % Generate a random frequency within the selected range
        Fc = selectedRange(1) + (selectedRange(2) - selectedRange(1)) * rand();
% %         fprintf('Random Frequency: %.2f MHz\n', Fc / 1e6);         
                                    % Convert to MHz for display
        Fc_small = 10e3;                   % Carrier frequency
        ini_phase = pi/8;        % Desired phase offset in radians

        time_win = 0.0213333333333333;    % time window of captured signal in

        %% needs to be updated for an AM receiver

        F_acc = rand * 5 -2.5;      % Frequency accuarcy ±2.5 PPM, 
        FrequencyOffset = (Fc * F_acc)/10e6;
                                    % Frequency offset of the VCO
        PhaseOffset = rand * 360; % Phase offset due to freq correction
        
        samplerateoffset = rand * 5 -2.5;   
                                    % ranges between ±2.5 PPM

        

        %% Data and modulation

        voice_file = 'song.wav';  % Replace with the path to your audio file
        [modSignal_1, Fs_graph] = audioread(voice_file);
%         Fs = 400e3;
        num_samp = 1024;% time_win*Fs;           % number of samples 
        
        t_1 = 0:1:1024;
        t_2 = 0:1/8:1024;
        t_1(end)=[];
        t_2(end)=[];
        t_1 = t_1';
        t_2 = t_2';

        % Take 1000 samples of y
        initial_sample = 3000;
        modSignal_1 = modSignal_1(initial_sample:(initial_sample+num_samp-1), 1);

%         figure(1)
%         subplot(2, 1, 1);
%         t = (0:length(x)-1) / Fs;  % Time vector
%         plot(t,real(x))
%         
%         subplot(2, 1, 2);
%         ModSignal = fft(x);
%         ModSignal = fftshift(ModSignal);
%         ns = length(x);
%         f = (0:ns-1) * Fs / ns;
%         plot(f, abs(ModSignal));
%         title('AM modulation (Frequency Domain)');
%         xlabel('Frequency (Hz)');
%         ylabel('Magnitude');
%         grid;

        figure(1)
        [SIGNAL_1,fVals_1]=freqDomainView(modSignal_1,Fs_graph,'single');
        [SIGNAL_2,fVals_2]=freqDomainView(modSignal_1,Fs_graph,'double');

        subplot(2,1,1); plot(fVals_1,abs(SIGNAL_1)); %sample values on x-axis
        title('X[f] SSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

        subplot(2,1,2); plot(fVals_2,abs(SIGNAL_2)); %x-axis represent frequencies
        title('X[f] DSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

%         interpolation_factor = int8(Fs_large/Fs);
%         x = interp(x,interpolation_factor);
%         x = interp1(t_1,x,t_2,"v5cubic");
        

        beta=4;
        fDev=(beta/2*pi)*360; 
%         Fs = 400e3;

        fmmodulator = comm.FMModulator( ...
           'SampleRate',Fs_graph, ...
           'FrequencyDeviation',fDev);

%         modSignal = fmmodulator(x);
        modSignal_2 = fmmod(modSignal_1,Fc_small,Fs_graph,fDev,ini_phase);
        
        figure(2)
        [SIGNAL_1,fVals_1]=freqDomainView(modSignal_2,Fs_graph,'single');
        [SIGNAL_2,fVals_2]=freqDomainView(modSignal_2,Fs_graph,'double');

        subplot(2,1,1); plot(fVals_1,abs(SIGNAL_1)); %sample values on x-axis
        title('X[f] SSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

        subplot(2,1,2); plot(fVals_2,abs(SIGNAL_2)); %x-axis represent frequencies
        title('X[f] DSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

%         figure(2)
%         subplot(2, 1, 1);
%         t = (0:length(modSignal_2)-1) / Fs;  % Time vector
%         plot(t,real(modSignal_2))
%         
%         subplot(2, 1, 2);
%         ModSignal = fft(modSignal_2);
%         ModSignal = fftshift(ModSignal);
%         ns = length(modSignal_2);
%         f = (0:ns-1) * Fs / ns;
%         plot(f, abs(ModSignal));
%         title('FM modulation (Frequency Domain)');
%         xlabel('Frequency (Hz)');
%         ylabel('Magnitude');
%         grid;
        
        figure(3)
        scatter(real(modSignal_2),imag(modSignal_2))

      
        %% Channel modeling
        distance = (0.5 + (100-0.1) * rand)*1e3;
        wavelength = 3e8/Fc;     
        
        max_velocity = rand * 60;       % K/hr
        fd = max_velocity/wavelength;
                                 % Maximum Doppler Shift in Hz
        
        doppler_spectrum = doppler('Jakes');
        
        ricianchan = comm.RicianChannel(...
                            'SampleRate',Fs_graph, ...    % careful incase you use a higher up conversion
                            'NormalizePathGains',true, ...
                            'DirectPathInitialPhase',0,...
                            'MaximumDopplerShift',fd,...
                            'DopplerSpectrum',doppler_spectrum,...
                            'RandomStream','mt19937ar with seed', ...
                            'Seed',73, ...
                            'PathGainsOutputPort',false);


        % Define the area options
        area_options = {'Rural', 'Urban', 'Dense Urban'};
        
        % Choose an area from the options
        area = area_options{randi(length(area_options))};
                
        % Define K-factor ranges for different areas
        if strcmp(area, 'Rural')
        
            mean_value_1 = 3;
            std_deviation_1 = 1;
            KFactor = mean_value_1 + std_deviation_1 * randn(1);
        elseif strcmp(area, 'Urban')
        
            mean_value_1 = 2.4;
            std_deviation_1 = 1;
            KFactor = mean_value_1 + std_deviation_1 * randn(1);
        
        elseif strcmp(area, 'Dense Urban')
        
            mean_value_1 = 1.6;
            std_deviation_1 = 1;
            KFactor = mean_value_1 + std_deviation_1 * randn(1);
        
        end
                    
        KFactorLin = 10.^(KFactor/10); % Linear units
        ricianchan.KFactor = KFactorLin;

        directpathdoppler = fd*rand;
        ricianchan.DirectPathDopplerShift = directpathdoppler;



        rayleighchan = comm.RayleighChannel( ...
            "NormalizePathGains",true, ...
            'SampleRate',          Fs_graph, ...    % careful incase you use a higher up conversion
            'MaximumDopplerShift', fd, ...
            'DopplerSpectrum',     doppler_spectrum, ...
            'RandomStream',        'mt19937ar with seed', ...
            'Seed',                99, ...
            'PathGainsOutputPort', false);
        
        awgnChan = comm.AWGNChannel('NoiseMethod', ...
                                   'Signal to noise ratio (SNR)', ...
                                   'SNR',0);
        
        path1delay = 0.05 + (5-0.05)*rand; 
        path2delay = 0.1 + (5-0.1)*rand;   
        path3delay = 0.15 + (5-0.1)*rand;  
        path4delay = 0.2 + (5-0.1)*rand;  
        
        path1gain = -35 + (3-(-35))*rand; 
        path2gain = -35 + (3-(-35))*rand; 
        path3gain = -35 + (3-(-35))*rand; 
        path4gain = -35 + (3-(-35))*rand; 
        
        
        rayleighchan.PathDelays = [path1delay path2delay path3delay path4delay]*1e-3;
        rayleighchan.AveragePathGains = [path1gain path2gain path3gain path4gain];

        ricianchan.PathDelays = [path1delay path2delay path3delay path4delay]*1e-3;
        ricianchan.AveragePathGains = [path1gain path2gain path3gain path4gain];

%         fadedSig = ricianchannel(modSignal);  % applying rician channel
        fadedSig = rayleighchan(modSignal_2);
    
        loss = fspl(distance, wavelength);
        pl_sig = db2pow((-loss+SNR(i))/2)*fadedSig;  % will be changed % the ranges from ITU is between 210 and 280, which is too low
                                                   % free space
        
        
        rxSig_1 = awgn(pl_sig,SNR(i),'measured');



        figure(4)
        [SIGNAL_1,fVals_1]=freqDomainView(rxSig_1,Fs_graph,'single');
        [SIGNAL_2,fVals_2]=freqDomainView(rxSig_1,Fs_graph,'double');

        subplot(2,1,1); plot(fVals_1,abs(SIGNAL_1)); %sample values on x-axis
        title('X[f] SSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

        subplot(2,1,2); plot(fVals_2,abs(SIGNAL_2)); %x-axis represent frequencies
        title('X[f] DSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

%         figure(4)
%         subplot(2, 1, 1);
%         t = (0:length(rxSig)-1) / Fs_graph;  % Time vector
%         plot(t,real(rxSig))
%         
%         subplot(2, 1, 2);
%         ModSignal = fft(rxSig);
%         ModSignal = fftshift(ModSignal);
%         ns = length(rxSig);
%         f = (0:ns-1) * Fs_graph / ns;
%         plot(f, abs(ModSignal));
%         title('AM with AWGN and Fading (Frequency Domain)');
%         xlabel('Frequency (Hz)');
%         ylabel('Magnitude');
%         grid;
        %% Hardware Impairments
        
        pfo = comm.PhaseFrequencyOffset(PhaseOffset=PhaseOffset, ...
            FrequencyOffset=FrequencyOffset, ...
            SampleRate=Fs_graph);

        rxSig_2 = pfo(rxSig_1);

        sro = comm.SampleRateOffset(samplerateoffset);
        rxSig_2 = sro(rxSig_2);

        % Define your variable
        size_to_check = num_samp;  
        
        % Check if the variable is equal to size_to_check
        
        if length(rxSig_2) > size_to_check
            % If it's larger, decrease it to size_to_check
            num_over_size = length(rxSig_2) - size_to_check ;
            rxSig_2 = rxSig_2(1:size_to_check);
            fprintf('It was larger \n');
        
        elseif length(rxSig_2) < size_to_check 
            % If it's less, increase complex zero elements at the beginning
            % to match the size of size_to_check
            lastElement = rxSig_2(end);
            numDuplicates = size_to_check - length(rxSig_2);
            duplicatedElements = repmat(lastElement, numDuplicates, 1);
            rxSig_2 = [rxSig_2; duplicatedElements];
            fprintf('It was samller \n');
        
        end

        figure(5)
        [SIGNAL_1,fVals_1]=freqDomainView(rxSig_2,Fs_graph,'single');
        [SIGNAL_2,fVals_2]=freqDomainView(rxSig_2,Fs_graph,'double');

        subplot(2,1,1); plot(fVals_1,abs(SIGNAL_1)); %sample values on x-axis
        title('X[f] SSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

        subplot(2,1,2); plot(fVals_2,abs(SIGNAL_2)); %x-axis represent frequencies
        title('X[f] DSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');
        %% BPF 8.5 kHz to 11.5 kHz
        rxSig_3 = FIR_BPF_analog_2(rxSig_2);


        figure(6)
        [SIGNAL_1,fVals_1]=freqDomainView(rxSig_3,Fs_graph,'single');
        [SIGNAL_2,fVals_2]=freqDomainView(rxSig_3,Fs_graph,'double');

        subplot(2,1,1); plot(fVals_1,abs(SIGNAL_1)); %sample values on x-axis
        title('X[f] SSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

        subplot(2,1,2); plot(fVals_2,abs(SIGNAL_2)); %x-axis represent frequencies
        title('X[f] DSM Modulated Signal'); xlabel('frequencies (f)'); ylabel('|X(f)|');

%         figure(5)
%         subplot(2, 1, 1);
%         t = (0:length(rxSig_2)-1) / Fs_graph;  % Time vector
%         plot(t,real(rxSig_2))
%         
%         subplot(2, 1, 2);
%         ModSignal = fft(rxSig_2);
%         ModSignal = fftshift(ModSignal);
%         ns = length(rxSig_2);
%         f = (0:ns-1) * Fs_graph / ns;
%         plot(f, abs(ModSignal));
%         title('AM Hardware impairments (Frequency Domain)');
%         xlabel('Frequency (Hz)');
%         ylabel('Magnitude');
%         grid;

        examples(:,index) = single(rxSig_3);  % checked number of decimal points
        SNR_values (:,index) = SNR(i);

        release(rayleighchan); 
        index = index+1;
    end
end

examples_IQ = cat(3,real(examples), imag(examples));
examples_IQ = permute(examples_IQ,[3,1,2]);


mod = repelem("4-FSK", i*k);
channel_type = repelem("rayleigh", i*k);

labels = cat(1,mod,channel_type);
file_name = 'DMR_4_FSK.mat';
save(file_name ,'examples_IQ','SNR_values','labels');
%% Profiling
toc;


