% this code is used to randomize the inputs of the ITU standard p.1546
%   [E, L] = P1546FieldStrMixed(f,t,heff,h2,R2,area,d_v,path_c,pathinfo);
%   [E, L] = P1546FieldStrMixed(2700,50,1600,1.5,10,'Suburban',20,'Land',1);
clear variables

Fc = 50;
t = 1 + (25 - 1)*rand;  % ranges between 1% and 50%
heff =  10 + (50 - 10)*rand; % ranges from 0m to 15m, and it can be higher
ha = heff;
h2 = 1 + (2 -1)*rand; % ranges from 1m to 2m

R2_ranges = [10, 15, 20];
shuffledranges = R2_ranges(randperm(length(R2_ranges)));
R2 = shuffledranges(1);

area_options = {'Rural', 'Urban', 'Dense Urban'};
shuffledoptions_1 = area_options(randperm(length(area_options)));
area = shuffledoptions_1{1};

d_v = 0.1 + (3 - 0.1)*rand; % distance ranges 100 m to 3 km
                            % and this is chosen in accorance with
                            % the least accepted tolerance among the
                            % different signal types
% hb = 0.2*d_v;
path_c = 'Land';
pathinfo = 0;

[E, L] = P1546FieldStrMixed(Fc/1e6,t,heff,h2,R2,area,d_v,path_c,pathinfo, ...
                        'ha',ha);

