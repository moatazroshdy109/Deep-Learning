function Fc = selectRandomFrequency_2()
    % Carrier frequency selection
    % frequency ranges according to DMR standard
    frequencyRanges = {
%         [148.5e3, 283.5e3]
%         [526.5e3, 1606.5e3] % These lines have been commented cause
                              % we are going to make the Intermediate
                              % frequency to be 455 kHz
        [3.2e6, 3.4e6]
        [3.95e6, 4e6]
        [4.75e6, 4.995e6]
        [5.005e6, 5.06e6]
        [5.9e6, 6.2e6]
        [7.2e6, 7.45e6]
        [9.4e6, 9.9e6]
        [11.6e6, 12.1e6]
        [13.57e6, 13.87e6]
        [15.1e6, 15.8e6]
        [17.48e6, 17.9e6]
        [18.9e6, 19.02e6]
        [21.45e6, 21.85e6]
        [25.67e6, 26.1e6]
        };

    % Choose a random range index
    numRanges = numel(frequencyRanges);
    randomRangeIndex = randi(numRanges);

    % Get the selected frequency range
    selectedRange = frequencyRanges{randomRangeIndex};

    % Generate a random frequency within the selected range
    Fc = selectedRange(1) + (selectedRange(2) - selectedRange(1)) * rand();
end
