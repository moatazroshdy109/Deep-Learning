function normalized_Matrix = normalizeComplexMatrix(inputArray)
    % Find the magnitude (absolute value) of the maximum element
    maxMagnitude = max(max(abs(inputArray)));

    % Normalize the array
    normalized_Matrix = inputArray ./ maxMagnitude;
end
