function [eye_data, t] = eyediagram_2(x, n, period, offset)
    narginchk(2, 4);
    nargoutchk(0, 2);

    if nargin < 3
        period = 1;
    else
        % convert PERIOD to Double data type if needed
        if ~isa(period, 'float')
            period = double(period);
        end
    end

    if nargin < 4
        offset = 0;
    else
        % convert OFFSET to Double data type if needed
        if ~isa(offset, 'float')
            offset = double(offset);
        end
    end

    % convert N to Double data type if needed
    if ~isa(n, 'float')
        n = double(n);
    end

    [r, c] = size(x);
    if r * c == 0
        error(message('comm:eyediagram:EmptyX'))
    end

    % Complex number processing
    if ~isreal(x)
        x = [real(x), imag(x)];
    end

    % generate normalized time values
    [len_x, ~] = size(x);
    t = rem((0 : (len_x - 1)) / n, 1)';

    % wrap right half of time values around to the left
    tmp = find(t > rem((offset / n + 0.5), 1) + eps^(2 / 3));
    t(tmp) = t(tmp) - 1;

    % if t = zero is at an edge, make it the left edge
    if max(t) <= 0
        t = t + 1;
    end

    % determine the right-hand edge points
    % for zero offset, the index value of the first edge is floor(n/2)+1
    index = fliplr(1 + rem(offset + floor(n / 2), n) : n : len_x);

    % for plotting, insert NaN values into both x and t after each edge point
    % to define the left edge, after the NaNs repeat the ith value of x
    % and insert a value that is (period/n) less than the (i+1)th value of t
    NN = NaN(1, c);
    for ii = 1:length(index)
        i = index(ii);
        if i < len_x
            x = [x(1:i, :); NN; x(i, :); x(i+1:end, :)];
            t = [t(1:i); NaN; t(i+1) - 1 / n; t(i+1:end)];
        end
    end

    % adjust the time values to ensure that the x-axis remains fixed
    half_n = n / 2 - 1;
    modoffset = rem(offset + half_n, n) - half_n;
    t = rem(t - modoffset / n, 1);

    % scale time values by period
    t = t * period;

    % Create eye_data
    eye_data = x;

end
