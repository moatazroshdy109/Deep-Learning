%% Intialization
clc
clear variables
num_samp=8*1024;
Decimation_factor=48000/6000; % 48000 original sampling frequency,
                              % and 6000 is the receiver sampling frequency
%% Load a voice audio file
voice_file = 'song.wav';  % Replace with the path to your audio file
[xsteady, fs] = audioread(voice_file);
% Take 1000 samples of y
initial_sample = 3000;
xsteady = xsteady(initial_sample:initial_sample+num_samp-1, 1);
t = (0:(length(xsteady)-1))*(1/fs);

%% FFT
NFFT = 2^nextpow2(length(xsteady));
% positive FFT frequency
freqfft = (0:(NFFT/2-1))*(fs/NFFT);
Xsteady = fft(xsteady,NFFT);

%% Spectrogram

Nspec = 256;
beta = 5;
wspec = hamming(Nspec);
Noverlap = Nspec/2;

[Ssteady, fspec, tspec] = ...
    stft(xsteady,fs,Window=kaiser(Nspec,beta), ...
    OverlapLength=Noverlap,FFTLength=NFFT,FrequencyRange="onesided");
%     spectrogram(xsteady,wspec,Noverlap,Nspec,fs);

figure(1)
subplot(211)
plot(freqfft,abs(Xsteady(1:NFFT/2)));
xlabel('Frequency (Hz)')
ylabel('|X(f)|')

subplot(212)
sdb = mag2db(abs(Ssteady));
% mesh(tspec,fspec,sdb)
waterfall(tspec,fspec,sdb)
cc = max(sdb(:))+[-60 0];
ax.CLim = cc;
% ylim([0 2e4])
view(90,90)
colorbar
ylabel("Frequency (Hz)")
xlabel("Time (s)");title("spectrogram");





