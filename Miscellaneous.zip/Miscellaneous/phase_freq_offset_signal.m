function [shifted_signal] = phase_freq_offset_signal(signal, phase_offset, frequency_offset, Fs)
    % Calculate the time vector based on the length of the input signal
    t = (0:length(signal)-1)/Fs;

    % Apply phase shift
    phase_shift_radians = deg2rad(phase_offset);
    phase_shifted_signal = signal .* exp(1j * phase_shift_radians);
    
    % Apply frequency shift
    frequency_shift_radians = 2*pi*frequency_offset;
    frequency_shifted_signal = phase_shifted_signal .* exp(1j * frequency_shift_radians * t.');

    % Return the shifted signal
    shifted_signal = frequency_shifted_signal;
end
