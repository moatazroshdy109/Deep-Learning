% % Example usage of the eye_diagram function
% 
% % Assuming you have a signal 'input_signal' and other parameters
% rolloff = 0.1;
% fs = 1000;
% N = 100;
% span = 10;
% sps = 8;
% 
% % Generate or obtain your input signal (replace this line with your actual signal)
% input_signal = randn(1, N * sps);
% 
% % Call the eye_diagram function
% [eye_data, t] = eye_diagram(input_signal, rolloff, fs, N, span, sps);

N = 100; % number of symbols
data = randi([0,1],1,N);
am = 2.*data -1;% converting to polar +1 & -1
fs = 10; % sampling rate
am_up = upsample(am,fs);
txfilter = comm.RaisedCosineTransmitFilter('OutputSamplesPerSymbol',sps);
txSig = txfilter(am_up);
% Call the modified eyediagram function
% [eye_data, t] = eyediagram(am_up, 2*fs);
[eye_data, t] = eyediagram(am_up, 2*fs);
% Plot the eye diagram
figure;
plot(t, real(eye_data), 'b');
title('Eye Diagram');
xlabel('Time');
ylabel('Amplitude');
grid on;
