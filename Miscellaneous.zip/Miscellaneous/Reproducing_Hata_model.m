% fc = selectRandomFrequency();   % carrier frequency
fc=900e6;
area = random_area_selection(); % Area type for channel modeling
hb = [30 50 70 100 150 200];                       % effective base station height [m]
hm = 1.5;                         % effective mobile height [m]
% distance = (0.1 + (3-0.1) * rand)*1e3;
distance = 0.1:0.01:3;
% loss = zeros(1,length(distance));
% loss_metro = zeros(1,length(distance));
loss_smallcity  = zeros(length(hb),length(distance));
% loss_suburban  = zeros(1,length(distance));
% loss_rural = zeros(1,length(distance));
%% Okumura-Hata Curves
for i=1:length(distance)-1
    %% Metropolitan
%     C=0;
%     if fc<=200 
%         aHm=8.29*((log10(1.54*hm))^2)-1.1;
%     else 
%         aHm=3.2*((log10(11.75*hm))^2)-4.97;
%     end
%     A = 69.55 + 26.16*log10(fc) - 13.82*log10(hb)-aHm;
%     B = 44.9 - 6.55*log10(hb);
%     loss_metro(i)=A+B*log10(distance(i))+C;
    %% Small city / Urban
    for j=1:length(hb)
        C=0; aHm = (1.1*log10(fc)-0.7)*hm-(1.56*log10(fc)-0.8);
        A = 69.55 + 26.16*log10(fc) - 13.82*log10(hb(j))-aHm;
        B = 44.9 - 6.55*log10(hb(j));
        loss_smallcity(j,i)=A+B*log10(distance(i))+C;
    end
    %% Suburban
%     aHm = (1.1*log10(fc)-0.7)*hm-(1.56*log10(fc)-0.8);
%     C=-2*((log10(fc/28)).^2)-5.4;
%     A = 69.55 + 26.16*log10(fc) - 13.82*log10(hb)-aHm;
%     B = 44.9 - 6.55*log10(hb);
%     loss_suburban(i)=A+B*log10(distance(i))+C;
    %% Rural
%     aHm = (1.1*log10(fc)-0.7)*hm-(1.56*log10(fc)-0.8);
%     C=-4.78*((log10(fc)).^2)+18.33*log10(fc)-40.98;
%     A = 69.55 + 26.16*log10(fc) - 13.82*log10(hb)-aHm;
%     B = 44.9 - 6.55*log10(hb);
%     loss_rural(i)=A+B*log10(distance(i))+C;
%     loss(i) = Hata_model(fc,distance(i),hb,hm,area);
end

% plot(distance,loss,'DisplayName', area)
% plot(distance, loss_metro, 'DisplayName', 'Metropolitan')
% hold on

for i = 1:length(hb)-1
    plot(distance, loss_smallcity, 'DisplayName', 'Small City')
end

% plot(distance, loss_suburban, 'DisplayName', 'Suburban')
% plot(distance, loss_rural, 'DisplayName', 'Rural')

xlabel("Distance [km]")
ylabel("Loss [dB]")
title("Okumura-Hata Curve")
grid on
legend();
hold off
