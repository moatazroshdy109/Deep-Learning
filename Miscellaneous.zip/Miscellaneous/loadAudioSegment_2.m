function [x, Fs_bb] = loadAudioSegment_2(voice_file, num_samp, initial_sample)
    % Load an audio segment from the specified file
    % Parameters:
    % - voice_file: Path to the audio file
    % - num_samp: Number of samples to extract
    % - initial_sample: Starting sample index

    % Read the audio file
    [x, Fs_bb] = audioread(voice_file);
    
    % Adjust initial_sample to wrap around if it exceeds array bounds
    initial_sample = mod(initial_sample, length(x));
    
    % Adjust initial_sample if range exceeds array bounds
    if initial_sample + num_samp > length(x)
        initial_sample = initial_sample - (length(x) - num_samp);
    end
    
    % Extract the specified number of samples starting from initial_sample
    x = x(initial_sample:(initial_sample + num_samp - 1), 1);
end
