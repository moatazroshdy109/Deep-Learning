Fc = selectRandomFrequency();   % carrier frequency
area = random_area_selection(); % Area type for channel modeling
hb = 200;                       % effective base station height [m]
hm = 3;                         % effective mobile height [m]
% distance = (0.1 + (3-0.1) * rand)*1e3;

%% Function Initialization

distance = 0.1:0.01:3;
loss = zeros(1,length(distance));
for i=1:length(distance)-1
loss(i) = Hata_model(Fc,distance(i),hb,hm,area);
end

plot(distance,loss)
xlabel("Distance [km]")
ylabel("Loss [dB]")
title("Okumura-Hata Curve")
grid on