f = 4; % frequency in MHz, ranges from 600 kHz to 20 MHz,
       % but I will always choose form 3 MHz to 20 MHz
wavelength = 3e8/f; % wavelength in meters but please confirm the equation 
d = 15; % distance in km ranges from 1km to 50 km
eta = 15;  % dielectric constant for fine or cloudy weather
sigma = 1e-3; % conductivity for fine or cloudy weather
beta = arctan((eta+1)*f/(1.8e4*sigma)); % phase constant
r_b = 0.26;       % Ratio between areas of occupied and unoccupied
                  % ratio portion of the propagation occupied
                  % by buldings to the total path, representing the
                  % density of the buildings in urban areas %%%%%%%%%%%%%
n_s = randi([1, 10]); % the number of building in the LOS path
n_b = randi([1, 10]); % the number of buildings less than the LOS path
                      % and naturally we would change these numbers
                      % according to the environment
r_s = n_s/n_b;  % Sight parameter, ratio of the number of the buildings
                % and other obstacles that are higher than or equal to the
                % line of sight
r_e = 0.2;           % environment parameter of the receiving site
                  % for Rural it ranges from 0 to 0.01
                  % for Suburban it ranges from 0.15 to 0.2
                  % for Urban it ranges from 0.2 to 0.6
                  % for indoor from outdoor it ranges between 0.3 and 0.99

h_t = 200;           % height of the transmitter 
h_r = 3;           % height of the receiver      



p = (-1.75e-4)*(f*cos(beta)/sigma)*(d*1e3/wavelength); % numerical distance
A = ((2+0.3*p)/(2+p+0.6*p^2)); 
                     % Attenuation factor of the ground
                     % the term -phi(p,eta,beta) has been ignored in this
                     % equation

L_f = fspl(f,d);     % free-space path loss function
L_g = -20*log10(A);  % Attenuation by the general ground surface                      
L_d = 16*log10(d);    % attenuation from the propagating distance,
                     % for the urban cases %%%%%%%%%%%%%%%%
                     % So, this value will be removed in case we change the
                     % scenario to something other than urban
L_b = 95*log10(1+r_b); % attenuation caused by the amount of buildings 
L_S = 80*log10(1+r_s); % Sight loss, originating from the buildings
        % are higher or equal to the line of sight
L_e = 125*log10(1+r_e); % Attenuation contributed by the environment at the receiving site,
        % accounting for the surronding building density and their heights
        % and the other obstacles around it.
if d<8*wavelength
        G_h = 10*(1+0.01*d)*log(h_t+h_r);
        % Gain component and is called the new height-gain factor
else
        G_h = 16*(1+0.01*d)*log(h_t+h_r);
end
PL = L_f + L_g + L_d + L_b + L_s + L_e - G_h;
