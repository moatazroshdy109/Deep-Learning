function outputSignal = shadowing(inputSignal, wavelength)

Lcorr=10;                   % Correlation distance in meters 
MM=0;                       % Larger area mean in dB
SS=5;                       % Larger area std or location variability in dB
F=4;                        % Sampling: Fraction of wavelength 

%=======================================================================

ds=wavelength/F;               % sample distance or something   
Nsamples=length(inputSignal);  % Number of samples to be generated  

% Fiter parameters =====================================================
cc=exp(-ds/Lcorr);
bb=SS*sqrt(1-cc^2);

A=[1 -cc];
B=1;

% Create Gaussian series ================================================
R=randn(Nsamples,1);
Rfiltered=filter(B,A,R)*bb;
Rfiltered=Rfiltered+MM;

outputSignal = inputSignal + Rfiltered; % Needs to be checked
end
