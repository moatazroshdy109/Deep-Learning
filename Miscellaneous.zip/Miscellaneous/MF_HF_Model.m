function PL = MF_HF_Model(d, f, area)
% Hata model for propagation loss
% Inputs:
%   - distance: distance in kilometers (1 km to 50 km)
%   - frequency: frequency in MHz (600 kHz to 20 MHz)
%   - scenario: string specifying the scenario ('Metropolitan', 'Small City', 'Suburban', 'Rural')
% Output:
%   - PL: path loss in dB

% Check if the input scenario is valid
valid_scenarios = {'metro', 'smallcity', 'suburban', 'rural'};
if ~ismember(area, valid_scenarios)
    error('Invalid scenario. Choose from: metro, smallcity, suburban, rural.');
end

% Define scenario-specific parameters based on the selected scenario
switch area
    case 'metro'
        r_b = 0.15 + (0.28 - 0.15) * rand();
        n_s = randi([3, 6]);
        n_b = randi([45, 55]);
        r_e = 0.6 + (0.75 - 0.6) * rand();
        L_d = 16*log10(d);   % attenuation from the propagating distance,
                     % for the urban cases %%%%%%%%%%%%%%%% So, this value
                     % will be removed in case we change the scenario to
                     % something other than urban
    case 'smallcity'
        r_b = 0.28 + (0.35 - 0.28) * rand();
        n_s = randi([1, 3]);
        n_b = randi([20, 45]);
        r_e = 0.2 + (0.6 - 0.2) * rand();
        L_d = 16*log10(d);
    case 'suburban'
        r_b = 0.55 + (0.75 - 0.55) * rand();
        n_s = randi([0, 1]);
        n_b = randi([10, 20]);
        r_e = 0.15 + (0.2 - 0.15) * rand();
        L_d = 0;   
    case 'rural'
        r_b = 0.75 + (0.95 - 0.75) * rand();
        n_s = 0;
        n_b = 2;
        r_e = 0 + (0.01 - 0) * rand();
        L_d = 0;   
end

% Rest of the parameters
eta = 15; % Dielectric constant for fine or cloudy weather
sigma = 1e-3; % Conductivity for fine or cloudy weather
beta = atan((eta + 1) * frequency / (1.8e4 * sigma)); % Phase constant
h_t = 200; % Height of the transmitter
h_r = 3; % Height of the receiver
wavelength = 3e8 / frequency; % Wavelength in meters
r_s = n_s/n_b;

p = (-1.75e-4)*(f*cos(beta)/sigma)*(d*1e3/wavelength); % numerical distance
A = ((2+0.3*p)/(2+p+0.6*p^2)); 
                     % Attenuation factor of the ground
                     % the term -phi(p,eta,beta) has been ignored in this
                     % equation

L_f = fspl(d, wavelength);     % free-space path loss function
L_g = -20*log10(A);  % Attenuation by the general ground surface                      

L_b = 95*log10(1+r_b); % attenuation caused by the amount of buildings 
L_s = 80*log10(1+r_s); % Sight loss, originating from the buildings
        % are higher or equal to the line of sight
L_e = 125*log10(1+r_e); % Attenuation contributed by the environment at the receiving site,
        % accounting for the surronding building density and their heights
        % and the other obstacles around it.
if d<8*wavelength
        G_h = 10*(1+0.01*d)*log(h_t+h_r);
        % Gain component and is called the new height-gain factor
else
        G_h = 16*(1+0.01*d)*log(h_t+h_r);
end
PL = L_f + L_g + L_d + L_b + L_s + L_e - G_h;
end
