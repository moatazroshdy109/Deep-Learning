% area = {'metro' 'smallcity' 'suburban' 'rural'};
% for k = 1:length(area);
%     
%     disp(area{k})
% end

% x=5;
% area = ["metro" "smallcity" "suburban" "rural"];
% for k = 1:length(area)
%     disp(["the number is" num2str(x)]) 
%     disp(['the number is' num2str(x)]) 
%     disp(calculateKFactorrandom_2(area(k)))
% end
%% First part
% Assign values to the two variables you want to keep
area_options = ["metro" "smallcity" "suburban" "rural"];
% area_options = ["iturHFLQ" "iturHFLM" "iturHFLD" "iturHFMQ" "iturHFMM" "iturHFMD" "iturHFMDV" "iturHFMDV" "iturHFHM" "iturHFHD"];

for k = 1:length(area_options)
    disp(area_options(k))

    %% second part 
    % Get a list of all variable names in the workspace
    allVariables = who;
    
    % Identify variables to clear (all except variable1 and variable2)
    variablesToClear = setdiff(allVariables, {'area_options', 'k'});
        %% third part
    if ~isempty(variablesToClear)
        % Clear the identified variables
        clear(variablesToClear{:});
    end
end