%% Initialization
clc
close all
clear variables

%% Loading Parameters

% Parameters
M = 16;                   % Modulation order
fc = 930e6;              % Carrier frequency
wavelength = 3e8/fc;     % with frequency ranges from 400 MHz to 470 MHz
                         % 136 MHz to 174 MHz, 800 MHz to 900 MHz,
                         % 900 MHz to 930 MHz
fs = 25e6;               % Sampling frequency
freqdev = 600;           % Frequency deviation for C4FM modulation
N = 10000;               % Number of samples
sampsPerSym = 4;         % Upsampling factor
phase_offset=pi/4;       % Phase offset
time_offset = 10;        % Parts per million
max_velocity = 60;       % K/hr
fd = max_velocity/wavelength;
                         % Maximum Doppler Shift in Hz

%% Generate Binary Bits from Audio Signal
symbols = randi([0,M-1],N,1);

%% Initialize the modulator
modSignal = pskmod(symbols,M,phase_offset,'gray'); %,sampsPerSym


% symgray = pskmod(data,M,phaseoffset,'gray','PlotConstellation',true, ...
%           'InputType','integer');

%% Channel initialization

% sro = comm.SampleRateOffset(time_offset);

channel = comm.AWGNChannel('NoiseMethod', ...
                           'Signal to noise ratio (SNR)', ...
                           'SNR',20);
                       
noisySignal = channel(modSignal);

%% Constellation diagram

% % data = (0:M-1)';           % Input signal
% % refconst = pskmod(data,M,phase_offset); % Reference constellation points
% % 
constdiagram = comm.ConstellationDiagram( ...
    'ReferenceConstellation',modSignal, ...
    'Title','Signal with Offset Sample Rate');
% % 
% % impairedData = sro(modSignal);
constdiagram(noisySignal)

% scatterplot(noisySignal)


%% Spectrum analyzer

specAnal = spectrumAnalyzer(SampleRate=fs,AveragingMethod="exponential",...
    PlotAsTwoSidedSpectrum=false,...
    RBWSource="auto",SpectrumUnits="dBW");
% specAnal = dsp.SpectrumAnalyzer(1,"AveragingMethod",);
% specAnal.SampleRate = fs;
specAnal(noisySignal)


