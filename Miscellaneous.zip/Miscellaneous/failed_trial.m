%% Shadowing parameters

if(strcmp(area,'Urban') || strcmp(area,'Dense Urban') )
    sigma_L = 4;
elseif (strcmp(area,'Suburban'))
    sigma_L = 6;
elseif (strcmp(area,'Rural') )
    sigma_L = 8;
else        
  fclose all;
  error('Wrong area! Allowed area types: Sea, Rural, Suburban, Urban, or Dense Urban.');
end


% Generate a random variable 'prob' with a uniform distribution between 0 and 1
prob = rand();

% Check the value of 'prob' using an if statement
if prob < 0.2
    fprintf('The value of prob is less than 0.2: %f\n', prob);
else
    fprintf('The value of prob is greater than or equal to 0.2: %f\n', prob);
end
