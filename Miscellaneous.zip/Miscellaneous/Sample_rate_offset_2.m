numFrames = 200;
numSymbolsPerFrame = 4096;
preambleLength = 64;
payloadLength = numSymbolsPerFrame - preambleLength; 
modulationOrder = 4;

rolloff = 0.2;
filterSpan = 10;
samplesPerSymbol = 8;
txFilter = comm.RaisedCosineTransmitFilter(RolloffFactor=rolloff, ...
    FilterSpanInSymbols=filterSpan, ...
    OutputSamplesPerSymbol=samplesPerSymbol);
rxFilter = comm.RaisedCosineReceiveFilter(RolloffFactor=rolloff, ...
    FilterSpanInSymbols=filterSpan, ...
    InputSamplesPerSymbol=samplesPerSymbol,DecimationFactor=1);


goldSeq = comm.GoldSequence(SamplesPerFrame=preambleLength);
preamble = goldSeq();
preamble(preamble==1)=2; 
preambleModOut = pskmod(preamble,modulationOrder,pi/modulationOrder);

preambleRefDelayed = rxFilter( ...
    txFilter([preambleModOut;zeros(filterSpan,1)]));
preambleRef = preambleRefDelayed( ...
    filterSpan*samplesPerSymbol+(1:samplesPerSymbol*preambleLength));


txPayload = pskmod( ...
    randi([0 modulationOrder-1],payloadLength,numFrames), ...
    modulationOrder, ...
    pi/modulationOrder);
txFrames = reshape([repmat(preambleModOut,1,numFrames);txPayload],[],1);
txSig = txFilter([txFrames;zeros(payloadLength,1)]);

simulatedSRO = 0.8;
sro = comm.SampleRateOffset(simulatedSRO);
rxSig = rxFilter(sro(txSig));


matchedFilterResponse = conj(flipud(preambleRef));
matchedFilterOutMag = abs(filter(matchedFilterResponse,1,rxSig));

threshold = max(matchedFilterOutMag)*0.7;
[~, peakLocations] = findpeaks(matchedFilterOutMag, ...
    MinPeakHeight=threshold, ...
    MinPeakDistance=preambleLength*samplesPerSymbol);
plot(matchedFilterOutMag)
title('Matched Filter Output (Magnitude)')
xlabel('Sample')
axis([0 numSymbolsPerFrame*samplesPerSymbol*10 ...
    -0.15*max(matchedFilterOutMag) 1.25*max(matchedFilterOutMag)]);
grid on


frameDelay = peakLocations - length(preambleRef);
constDiag = comm.ConstellationDiagram(Title='Received Payload', ...
    Position=[20 70 600 600]);
evm = comm.EVM;
evmScope = timescope(TimeUnits='none',TimeSpan=length(frameDelay), ...
    YLabel='EVM (%)',YLimits=[0 15],TimeAxisLabels='none', ...
    Position=[650 120 800 500]);
for i = 1:length(frameDelay)
    rxFrame = rxSig(frameDelay(i) + ...
        (1:samplesPerSymbol:numSymbolsPerFrame*samplesPerSymbol));
    evmScope(evm(txPayload(:,i),rxFrame(preambleLength+1:end)));
    constDiag(rxFrame(preambleLength+1:end));
    pause(0.1)
end

peakSpacings = diff(peakLocations);
nominalPeakSpacing = numSymbolsPerFrame*samplesPerSymbol;
estimatedSRO = (mean(peakSpacings)/nominalPeakSpacing-1)*1e6




