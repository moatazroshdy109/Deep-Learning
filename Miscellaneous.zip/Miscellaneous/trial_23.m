%     dt = 1/44100;
%     t=0:dt:(117204*dt)-dt;                    
%     x = chirp(t,1500,1,8000);
%     S = zeros(501,117);
%     windowlength = 1e3;
%     k = 1;
%     for jj = 1:117
%         y = x(k:k+windowlength-1)';
%         ydft = fft(y).*gausswin(1e3);
%         S(:,jj) = ydft(1:501);
%         k = k+windowlength;
%     end
%     F = 0:44100/1000:44100/2;
%     T = 0:(1e3*dt):(117000*dt)-(1e3*dt);
%     surf(T,F,20*log10(abs(S)),'EdgeColor','none')
%     axis xy; axis tight; colormap(jet); view(0,90);
%     xlabel('Time');
%     ylabel('Frequency (Hz)');


    win = gausswin(1e3);
    dt = 1/44100;
    t=0:dt:(117204*dt)-dt;                    
    x = chirp(t,1500,1,8000);
    [S,F,T,P] = spectrogram(x,win,900,length(win),44100);
    surf(T,F,10*log10(P),'EdgeColor','none')
    axis xy; axis tight; colormap(jet); view(0,90);
    xlabel('Time');
    ylabel('Frequency (Hz)');