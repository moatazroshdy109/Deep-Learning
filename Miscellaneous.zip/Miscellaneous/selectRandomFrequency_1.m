function Fc = selectRandomFrequency_1()
    % Carrier frequency selection
    % frequency ranges according to DMR standard
    frequencyRanges = {
        [30e6, 300e6]    % Range 1: VHF
        [300e6, 3000e6]    % Range 2: UHF
    };

    % Choose a random range index
    numRanges = numel(frequencyRanges);
    randomRangeIndex = randi(numRanges);

    % Get the selected frequency range
    selectedRange = frequencyRanges{randomRangeIndex};

    % Generate a random frequency within the selected range
    Fc = selectedRange(1) + (selectedRange(2) - selectedRange(1)) * rand();
end
