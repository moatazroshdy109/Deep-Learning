function rxSig_2 = adjustRxSigSize(rxSig_2, size_to_check)
    % Check if the variable is equal to size_to_check
    if length(rxSig_2) > size_to_check
        % If it's larger, decrease it to size_to_check
        rxSig_2 = rxSig_2(1:size_to_check);
%         fprintf('It was larger \n');
    elseif length(rxSig_2) < size_to_check
        % If it's less, increase complex zero elements at the beginning
        % to match the size of size_to_check
        lastElement = rxSig_2(end);
        numDuplicates = size_to_check - length(rxSig_2);
        duplicatedElements = repmat(lastElement, numDuplicates, 1);
        rxSig_2 = [rxSig_2; duplicatedElements];
%         fprintf('It was smaller \n');
    end
end
