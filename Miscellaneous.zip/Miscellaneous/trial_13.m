% Set a constant increment value
constant_increment = 2;

% Number of iterations
num_iterations = 5;

% Initialize a variable to store the constant value
constant_value = 0;

% Loop through different iterations
for i = 1:num_iterations
    % Increment the constant value
    constant_value = constant_value + constant_increment;

    % Display the current constant value
    fprintf('Iteration %d: Constant Value = %d\n', i, constant_value);
end
