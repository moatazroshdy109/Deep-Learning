function normalizedArray = normalizeComplexArray(inputArray)
    % Find the magnitude (absolute value) of the maximum element
    maxMagnitude = max(abs(inputArray));

    % Normalize the array
    normalizedArray = inputArray / maxMagnitude;
end
