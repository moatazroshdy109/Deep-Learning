clear variables
% Parameters
t = 1 + (50 - 1)*rand;  % ranges between 1% and 50%
path_c = 'Land';
pathinfo = 0;

area_options = ["metro" "smallcity" "suburban" "rural"];

distance_start = 1; % Starting distance in km
distance_end = 2;   % Ending distance in km
distance_increment = 0.05;  % Increment in distance in km

frequency_start = 30;  % Starting frequency in Hz (30 MHz)
frequency_end = 3000;  % Ending frequency in Hz (3000 MHz)
frequency_increment = 100;  % Increment in frequency in Hz (100 MHz)

% Generate distance values
distances = distance_start:distance_increment:distance_end;

% Generate frequency values
frequencies = frequency_start:frequency_increment:frequency_end;

% Initialize matrix to store FSPL values
losses_matrix = zeros(length(distances), length(frequencies));

% Calculate ITU-1546 for each combination of distance and frequency
for k = 1:length(area_options)
    area = area_options(k);
    for i = 1:length(distances)
        for j = 1:length(frequencies)
            losses_matrix(i, j) = P1546_loss(frequencies(j), distances(i), area_options(k));
        end
    end
    % Plot the results
%     figure(k);
%     surf(frequencies, distances, losses_matrix);
%     xlabel('Frequency (MHz)');
%     ylabel('Distance (km)');
%     zlabel('Losses (dB)');
%     title(convertStringsToChars(area),'ITU-1546 Losses');
end

