s1 = [ones(500,1); -ones(500,1)];
modSig = 0.7071 * complex(s1(randperm(1000)), s1(randperm(1000)));
sps = 8;
filtSig = resample(modSig, sps, 1);
h=figure(1);
title("")
eyediagram(filtSig, 2*sps,1,0,'y-',h);
