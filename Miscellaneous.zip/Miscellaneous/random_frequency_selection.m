% Define multiple frequency ranges as cell arrays
frequencyRanges = {
    [136e6, 174e6]   % Range 1: VHF
    [400e6, 470e6]   % Range 2: UHF
    [806e6, 930e6]    % Range 3: 800/900 MHz
};

% Choose a random range index
numRanges = numel(frequencyRanges);
randomRangeIndex = randi(numRanges);

% Get the selected frequency range
selectedRange = frequencyRanges{randomRangeIndex};

% Generate a random frequency within the selected range
randomFrequency = selectedRange(1) + (selectedRange(2) - selectedRange(1)) * rand();

% Display the randomly generated frequency and the selected range
fprintf('Selected Range: %.2f MHz to %.2f MHz\n', selectedRange / 1e6); % Convert to MHz for display
fprintf('Random Frequency: %.2f MHz\n', randomFrequency / 1e6);         % Convert to MHz for display
