function waterplot(s,f,t)
% Waterfall plot of spectrogram
    waterfall(f,t,abs(s)'.^2)
% %     set(gca,XDir="reverse",View=[30 50])
%     set(gca,XDir="normal",View=[0 200])
    xlabel("Frequency (Hz)")
    ylabel("Time (s)")
end