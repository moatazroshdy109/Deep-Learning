%% Initialization
clc
close all
clear variables
%% Loading Parameters
tic;

num_examples = 1; % this should be be 200 to 500



index = 1;
  % 1000 example, each example contains 1024 sample
fprintf('Iteration no.: %.0f \n', index);
% Carrier frequency selection
% frequency ranges according to DMR standard
frequencyRanges = {
    [136e6, 174e6]    % Range 1: VHF
    [400e6, 470e6]    % Range 2: UHF
    [806e6, 930e6]    % Range 3: 800/900 MHz  % its upper range is 941 MHz
};

% Choose a random range index
numRanges = numel(frequencyRanges);
randomRangeIndex = randi(numRanges);

% Get the selected frequency range
selectedRange = frequencyRanges{randomRangeIndex};

% Generate a random frequency within the selected range
Fc = selectedRange(1) + (selectedRange(2) - selectedRange(1)) * rand();
% %         fprintf('Random Frequency: %.2f MHz\n', Fc / 1e6);         
                            % Convert to MHz for display

Fs = 25e6;%25e6;            % Sampling frequency according NI-USRP 2030
R_s = 4800;                 % symbol rate

freqSep = R_s*1;            % Frequency deviation for modulation
                            % +3 --> +1,944 kHz, +1 --> 0.648 kHz 
F_if = 10.7e6;              % Intermediate frequency  % needs to be checked
%         time_win = 2*0.3950617283950617;      % time window of captured signal in
time_win = 0.00004096;                     % seconds with a total of 0.08 = 80 ms 
                            % or in otherwords, it is the 1024 
                            % which is number of samples per 
                            % example = 40 µs

M = 4;                      % Modulation order
num_bps = log2(M);          % number of bits per symbol according 
                            % to the modulation order   
sps = 8;                    % Samples per symbol
        
spb = sps/num_bps;          % meaning that each symbol has 8 samples
                            % samples per bits %% change to be originated from symbols

num_samp = time_win*Fs;     % number of samples 
num_bits = num_samp/spb;    % number of bits

num_sym = num_bits/num_bps; % number of symbols cause the modulation order
                            % is 4-FSK     
Ts = sps/Fs;                % Symbol time period

F_acc = rand * 5 -2.5;      % Frequency accuarcy ±2.5 PPM
FrequencyOffset = (Fc * F_acc)/10e6;
                            % Frequency offset of the VCO
PhaseOffset = rand * 360; % Phase offset due to freq correction

samplerateoffset = rand * 5 -2.5;   
                            % ranges between ±2.5 PPM

InterpolationFactor_1 = 652;
InterpolationFactor_2 = round(((Fc*5.5)/Fs)/InterpolationFactor_1);


%% Data and modulation



                    % check the number of bits to make sure all the
                    % examples are similar


fskmod_bit = comm.FSKModulator(M,freqSep,R_s,...
        BitInput=true, ...
        SamplesPerSymbol=sps, ...
        ContinuousPhase=true, ...
        SymbolMapping="Gray");

fskdemodulator = comm.FSKDemodulator(M,freqSep,R_s, ...
        BitOutput=true, ...
        SamplesPerSymbol=sps, ...
        SymbolMapping="Gray");

Fs_graph = sps*R_s;

%% Up-Conversion

upConv_1 = dsp.DigitalUpConverter('InterpolationFactor',InterpolationFactor_1,...
        'SampleRate',Fs_graph,...
        'Bandwidth',25e3,...
        'PassbandRipple',0.28, ...
        'CenterFrequency',F_if);




%% LPF 20 MHz
% modSignal_3 = FIR_filter_trial_4_LPF(modSignal_2);



%% Square root raised cosine
SRRC = comm.RaisedCosineTransmitFilter("Shape", "Square root", ...
    "FilterSpanInSymbols", 1, ...
    "RolloffFactor",0.2, ...
    "Gain",1, ...
    "OutputSamplesPerSymbol",8);




Decimation_factor = InterpolationFactor_1 * SRRC.OutputSamplesPerSymbol;

downConv_2 = dsp.DigitalDownConverter('DecimationFactor',Decimation_factor,...
'SampleRate',Fs_graph*InterpolationFactor_1*SRRC.OutputSamplesPerSymbol,...
'Bandwidth',25e3,...
'PassbandRipple',0.28, ...
'CenterFrequency',F_if);


%% Channel initialization

awgnchan = comm.AWGNChannel( ...
    NoiseMethod="Signal to noise ratio (SNR)", ...
    SNR=-2);

errRate = comm.ErrorRate;

%% Transmission
SNR = 4:2:20;

for i = 1:length(SNR) 
    for counter = 1:100
        Data = randi ([0 1], round(num_bits), 1);   
        modSignal_1 = fskmod_bit(Data);
        modSignal_2 = upConv_1(modSignal_1);
        modSignal_3 = FIR_filter_trial_4_LPF(modSignal_2);
        modSignal_4 = SRRC(modSignal_3);
        noisySignal_1 = awgnchan(modSignal_4);
        rxSig_1 = FIR_filter_trial_5_LPF(noisySignal_1);
        noisySignal_2 = downConv_2(rxSig_1);
        rxSig_2 = FIR_filter_trial_6_LPF(noisySignal_2);
        receivedData = fskdemodulator(rxSig_2);
        errorStats = errRate(Data,receivedData);
        examples(:,index) = errorStats;  % checked number of decimal points
        SNR_values (:,index) = SNR(i);
        index = index+1;
    end
end

%% Error

es1 = 'Error rate = %4.2e\n';
es2 = 'Number of errors = %d\n';
es3 = 'Number of symbols = %d\n';
fprintf([es1 es2 es3],errorStats)






