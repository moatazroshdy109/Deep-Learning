% Gen AWGN QPSK data
I = sqrt(2)/2 * (2*randi(2,1000,1) - 3) + 1e-1*randn(1000,1);
Q = sqrt(2)/2 * (2*randi(2,1000,1) - 3) + 1e-1*randn(1000,1);
% apply IQ offest
Fc=50e6;
R_s = 4800;                     % symbol rate
sps = 8;                        % Samples per symbol
Fs_bb = R_s*sps;
F_acc = rand * 5 -2.5;
phi = 20;
FrequencyOffset = (Fc * F_acc)/1e6;
% I_o = kI*I;
% Q_o = kQ*cos(phi)*Q - kQ*sin(phi)*I;
signal = I + 1i * Q;
pfo = comm.PhaseFrequencyOffset(PhaseOffset=phi, ...
            FrequencyOffset=FrequencyOffset,...
            SampleRate=Fs_bb);
complexOutput = pfo(signal);
% complexOutput = applyIQimbalance(signal, kI, kQ, phi);
I_o = real(complexOutput);
Q_o = imag(complexOutput);
figure(1)
scatter(I,Q); hold on;
scatter(I_o,Q_o); title('QPSK Waveform');
xlabel('In-phase'); ylabel('Quadriture');
legend('No IQ Offset','IQ Offset'); xlim([-1.5 1.5]); ylim([-1.5 1.5]);
hold off

