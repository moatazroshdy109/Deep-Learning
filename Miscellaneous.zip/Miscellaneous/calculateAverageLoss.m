function average_loss = calculateAverageLoss(Fc, mid_distance, area)
% This function calculates the average loss of changing the distance 
% from -10λ to 10λ, where λ is the wavelength of the transmitted signal
% the input of the function is 
% Fc ... carrier frequency in Hz
% distance ... distance in meters
% area is defined between one of the following values 
% - 'metro','smallcity','suburban' or 'rural'
    c = physconst('LightSpeed');
    lambda = c / (Fc);
    num_iterations = 20; % -10λ to 10λ
    loss_values = zeros(num_iterations,1);
    initial_distance = mid_distance - (num_iterations/2) * lambda;
     for i = 1:num_iterations
        distance = initial_distance + i * lambda;
        loss_values(i) = P1546_loss(Fc / 1e6, distance / 1e3, area);
     end
    average_loss = mean(loss_values);
