function complexOutput = applyIQimbalance(signal, kI, kQ, phi)
    % Apply IQ offset to the complex signal
    % phi is in degree, and KI, KQ are in percentage (ex: 0.90, 0.70)
    % Extract real and imaginary components of the input signal
    I = real(signal);
    Q = imag(signal);
    phi = phi*pi/180;
    % Apply IQ offset
    I_o = kI * I;
    Q_o = kQ * cos(phi) * Q - kQ * sin(phi) * I;

    % Combine in-phase and quadrature components back into a complex signal
    complexOutput = I_o + 1i * Q_o;
end
