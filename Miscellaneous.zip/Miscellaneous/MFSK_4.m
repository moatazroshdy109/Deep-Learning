%% Initialization
clc
close all
clear variables
%% Loading Parameters

% Parameters
M = 4;              % Modulation order
Fc = 50e6;        % Carrier frequency
Fs = 2880;          % Sampling frequency
freqdev = 648;      % Frequency deviation for modulation
                    % +3 --> +1,944 kHz, +1 --> 0.648 kHz 

% for some reason there shoulf be a ratio of 4 between the sampling freq.
% and the frequency deviation

InterpolationFactor = round((Fc*3)/Fs);
N = 1000;       % Number of samples
sampsPerSym = 8;     % Upsampling factor
phase_offset=pi/8;

%% Generate Binary Bits from Audio Signal
symbols = randi([0,M-1],N,1);

%% Initialize the modulator

modSignal = fskmod(symbols,M,freqdev,sampsPerSym,Fs);

specAnal = dsp.SpectrumAnalyzer;
specAnal.SampleRate = Fs;
specAnal(modSignal)
%% Square root raised cosine
SRRC = comm.RaisedCosineTransmitFilter("Shape", "Square root", ...
    "FilterSpanInSymbols", 10, ...
    "RolloffFactor",0.2, ...
    "Gain",1, ...
    "OutputSamplesPerSymbol",8);

modSignal = SRRC(modSignal);




upConv = dsp.DigitalUpConverter('InterpolationFactor',InterpolationFactor,...
'SampleRate',Fs,...
'Bandwidth',12.5e3,...
'CenterFrequency',Fc);

% modSignal = upConv(modSignal);

%% Channel initialization

% % channel = comm.AWGNChannel('NoiseMethod', ...
% %                            'Signal to noise ratio (SNR)', ...
% %                            'SNR',0);
% %                        
% % % noisySignal = channel(modSignal);
%% IQ
% 
% % Extract in-phase (I) and quadrature (Q) components with correct phase shifts
% 
% % i_component = real(modSignal .* exp(-1i*phase_offset));
% % q_component = imag(modSignal .* exp(-1i*phase_offset));
% 
% % Plot the 4-FSK modulated signal in the time domain
% figure();
% subplot(2, 1, 1);
% t = (0:length(real(modSignal))-1) / Fs;  % Time vector
% plot(t, real(modSignal));
% title('4-FSK Modulated Signal (Real Part)');
% xlabel('Time (s)');
% ylabel('Amplitude');
% subplot(2, 1, 2);
% plot(t, imag(modSignal));
% title('4-FSK Modulated Signal (Imaginary Part)');
% xlabel('Time (s)');
% ylabel('Amplitude');
% 
% % figure();
% % subplot(2, 1, 1);
% % t = (0:length(real(modSignal))-1) / Fs;  % Time vector
% % plot(t, i_component);
% % title('4-FSK Modulated Signal (Real Part)');
% % xlabel('Time (s)');
% % ylabel('Amplitude');
% % subplot(2, 1, 2);
% % plot(t, q_component);
% % title('4-FSK Modulated Signal (Imaginary Part)');
% % xlabel('Time (s)');
% % ylabel('Amplitude');
% 
% % Plot the 4-FSK modulated signal in the frequency domain
% figure();
% % subplot(2, 1, 1);
% l=1:length(real(modSignal));
% 
% plot(((l-1)*(Fs/length(real(modSignal))-1)), abs(fftshift(fft(modSignal))) * (1 / N));
% % axis([-(10^4), 10^4, 0, 0.5]);
% xlabel('Frequency (Hz)');
% ylabel('Magnitude');
% title('4-FSK Modulated Signal Frequency Spectrum');

%% Demodulation

% % gmskdemodulator = comm.GMSKDemodulator('BitOutput',true, ...
% %                                  'InitialPhaseOffset',pi/4);
% % receivedData = gmskdemodulator(noisySignal);


% Ref  https://www.mathworks.com/help/comm/ref/comm.gmskmodulator-system-object.html#bsnan5p-6_1