  rctFilt = comm.RaisedCosineTransmitFilter('OutputSamplesPerSymbol', 8);
  fvtool(rctFilt, 'Analysis', 'impulse')
  x = 2*randi([0 1], 100, 1) - 1;
  y = rctFilt(x); 
  plot(y); grid on