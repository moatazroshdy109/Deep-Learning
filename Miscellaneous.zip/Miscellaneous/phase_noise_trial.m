pnoise = comm.PhaseNoise('Level',-50,'FrequencyOffset',20);

M = 16; % From 16-QAM
data = randi([0 M-1],1000,1);
modData = qammod(data,M);

y = pnoise(modData);
scatterplot(y)