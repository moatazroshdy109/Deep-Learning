% Modulation parameters
M = 16; % Modulation order
data = (0:M-1)';
modulationOrder = 16;

% Modulate data
modData = qammod(repmat(data, 100, 1), M);

% Create SampleRateOffset object
sro = comm.SampleRateOffset(50); % 50 parts per million

% Introduce sample rate offset
impairedData = sro(modData);
impairedData = adjustRxSigSize(impairedData, size_to_check);

% Time vector
time = (0:length(modData)-1);

% Plot the results
figure;

subplot(2, 1, 1);
plot(time, real(modData), 'LineWidth', 2);
title('Original Signal');
xlabel('Time');
ylabel('Amplitude');

subplot(2, 1, 2);
plot(time, real(impairedData), 'LineWidth', 2);
title('Signal with Sample Rate Offset');
xlabel('Time');
ylabel('Amplitude');

sgtitle('Time-Domain Illustration of Sample Rate Offset');
