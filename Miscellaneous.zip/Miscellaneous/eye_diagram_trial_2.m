% Program for plotting eye diagram of pulse shaped signal using
% raised cosine pulse using inbuilt functions

close all;
clear;

rolloff_1 = 0.1; % alpha =0.1
rolloff_5 = 0.5; % alpha =0.5

span = 10; % Filter span in symbols
sps = 8; % Samples per symbol
N=100; % No of symbols
BP_Data = 2*randi([0 1],N, 1) - 1; % generating radom polar sequence
                                   % of +1 & -1

% square root raised cosine filter for alpha values
rctFilt1 = rcosdesign(rolloff_1, span, sps,'sqrt');
rctFilt5 = rcosdesign(rolloff_5, span, sps,'sqrt');
% upsampling the transmit sequence and filtering with pulse generated
UP_s1 = upfirdn(BP_Data, rctFilt1, sps,1);
UP_s5 = upfirdn(BP_Data, rctFilt5, sps,1);

% Plotting the the signal
figure;
subplot(2,1,1); plot(UP_s1);title('eye diagram with alpha=0.1')
subplot(2,1,2); plot(UP_s5); title('eye diagram with alpha=0.5')
% Plotting the eye diagram using in built function
eyediagram(UP_s1, 2*sps),title('eye diagram with alpha=0.1')
eyediagram(UP_s5, 2*sps),title('eye diagram with alpha=0.5')



    