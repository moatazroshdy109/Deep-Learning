% This code is for the creation of the path loss and shadowing effect
% arrays, it will be generated and stored in a mat file and called upon for
% two reason, one is create a signal with multiple path loss effect and 
load('path_loss_metro.mat');
%%
area_options = ["metro" "smallcity" "suburban" "rural"];
SNR_factor = pow2db((25e6/2)/25e3);


frequency_start = 30e6;           % Starting frequency in Hz (30 MHz)
frequency_end = 3000e6;           % Ending frequency in Hz (3000 MHz)
frequency_increment = 100e6;      % Increment in frequency in Hz (100 MHz)
frequencies = frequency_start:frequency_increment:frequency_end;
                                % Generate frequency values
SNR = (-20:2:20) - SNR_factor;
num_examples = 15; 

for k = 1:length(area_options)
    %% Constant parameters
    tic;
    
    loss_1 = zeros(1,num_examples*length(frequencies)*length(SNR));
    loss_2 = zeros(1,num_examples*length(frequencies)*length(SNR));
%     loss_difference_1 = zeros(1,num_examples*length(frequencies)*length(SNR));
%     loss_3 = zeros(1,num_examples*length(frequencies)*length(SNR));
%     loss_4 = zeros(1,num_examples*length(frequencies)*length(SNR));
%     loss_difference_2 = zeros(1,num_examples*length(frequencies)*length(SNR));
%     shadowing_effect = zeros(1,num_examples*length(frequencies)*length(SNR));
    
    
    h = waitbar(0, 'Processing...');            % Initialize the waitbar
    index_1 = 1;
    for i = 1:length(SNR)
        for j = 1:length(frequencies)
            for example = 1:num_examples   % 15 example
                %% Variable parameters randomly generated every loop
    
                fprintf('Iteration no.: %.0f \n', index_1);
                
                Fc = frequencies(j) + (example - 1) * (frequency_increment / num_examples);   
                area = area_options(k);         % Area type for the channel 
                distance = (1 + (2-1) * rand)*1e3;
                                                % Distance from 1 to 2 Km
                q_value_1 = 1;                  % q = 1 % location 
                                                % variability 
                q_value_2 = 50 + (99 - 50) * rand;
                                                % q = 50 % --> 99% location
                                                % variability
                                                % the probabilty of 
                                                % occurance is 40 % in time
                loss_1(1,index_1) = P1546_loss_2(Fc / 1e6, distance / 1e3, ...
                    area,q_value_1); 
                            % path loss calculation AT Q =1 , no shadowing 
                loss_2(1,index_1) = P1546_loss_2(Fc / 1e6, distance / 1e3, ...
                    area, q_value_2); 
                            % Q = 50 -- 99%

%                 loss_1(1,index_1) = calculateAverageLoss(Fc, distance, area); % path loss calculation AT Q =1 , no shadowing 
%                 loss_2(1,index_1) = calculateAverageLoss(Fc, distance, area);
%                 loss_difference_1(1,index_1) = loss_1(1,index_1) - loss_2(1,index_1);
%                 loss_3(1,index_1) = P1546_loss(Fc / 1e6, distance / 1e3, area); % Q = 50 -- 99%
%                 loss_4(1,index_1) = P1546_loss(Fc / 1e6, distance / 1e3, area);
%                 loss_difference_2(1,index_1) = loss_3(1,index_1) - loss_4(1,index_1);
%                 shadowing_effect(1,index_1) = abs(loss_1(1,index_1) - loss_3(1,index_1));
                                                                              % shadowing loss calculation

                index_1 = index_1 + 1;
            end
        end
    end
    %% Saving the data
    
    close(h);           % Close the waitbar when the processing is complete
    file_name = ['path_loss_',convertStringsToChars(area),'.mat'];
    save(file_name ,'loss_1','loss_2');
    toc

end




