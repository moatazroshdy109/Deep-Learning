
area_options = ["metro" "smallcity" "suburban" "rural"];

Fc = selectRandomFrequency_1(); % carrier frequency
R_s = 4800;                     % symbol rate
sps = 8;                        % Samples per symbol
Fs_bb = R_s*sps;                % Sampling frequency baseband
freqSep = R_s*1;                % Frequency deviation
F_if = 10.7e6;                  % Intermediate frequency
M = 4;                          % Modulation order
num_bps = log2(M);              % Bits per symbol
spb = sps/num_bps;              % Samples per bits
num_samp = 1024;                % Required number of samples per
                                % example
num_bits = num_samp/spb;        % Number of bits
num_sym = num_bits/num_bps;     % number of symbols
k=4; % rural
area = area_options(k);             % Area type for channel modeling

F_acc = rand * 5 -2.5;          % Frequency accuarcy ±2.5 PPM
FrequencyOffset = (Fc * F_acc/1e6)/1e6;
                                % Frequency offset of the VCO
PhaseOffset = rand * 360;       % Phase offset due to freq 
                                % correction
samplerateoffset = rand * 5 -2.5;   
                                % ranges between ±2.5 PPM
kI = 1 - (0.0583 + (1.818 - 0.0583)*rand);
kQ = 1 - (0.0583 + (1.818 - 0.0583)*rand);
phi = -(4 + (12 - 4)*rand);
InterpolationFactor_1 = 652;    % Interpolation of the DUC
Decimation_factor = InterpolationFactor_1;
                                % Decimation of the DDC
Fs_if = Fs_bb*InterpolationFactor_1;
                                % Sampling frequency of IF
distance = (0.1 + (3-0.1) * rand);
                                % Distance up to 3 Km
wavelength = 3e8/Fc;            % Wavelength
max_velocity = rand * 60 * (1000/3600);
                                % Maximum velocity
fd = max_velocity/wavelength;   % Maximum doppler frequency

path1delay = 0.05 + (10 - 0.05) * rand;  
path2delay = 0.1 + (10 - 0.1) * rand;   
path3delay = 0.15 + (10 - 0.1) * rand;  
path4delay = 0.2 + (10 - 0.1) * rand;  
PathDelays = [path1delay, path2delay, path3delay, path4delay] * 1e-6;

path1gain = -15 + (3 - (-15)) * rand; 
path2gain = -15 + (3 - (-15)) * rand; 
path3gain = -15 + (3 - (-15)) * rand; 
path4gain = -15 + (3 - (-15)) * rand;
AveragePathGains = [path1gain, path2gain, path3gain, path4gain];
%% Channel generation

doppler_spectrum = doppler('Jakes');

% frequency flat fadding
fs_chan = 3.84e6;

ricianchan_1 = comm.RicianChannel(...
    'SampleRate',           fs_chan, ...    
    ...             % careful incase you use a higher up conversion
    'NormalizePathGains',   true, ...
    'DirectPathInitialPhase',0,...
    'MaximumDopplerShift',  fd,...
    'DopplerSpectrum',      doppler_spectrum,...
    'RandomStream',         'mt19937ar with seed', ...
    'Seed',                 73, ...
    ...'PathGainsOutputPort',  false, ...
    'KFactor',              calculateKFactorrandom_2(area), ...
    'DirectPathDopplerShift',fd*rand, ...
    'PathDelays',           path1delay, ...
    'AveragePathGains',     path1gain, ...
    'Visualization',        'Impulse and frequency responses', ...
    'ChannelFiltering',false);  %%%%%% This property must be adjusted when
                                %%%%%% the program is used to be true

% frequency selective fadding

% ricianchan_2 = comm.RicianChannel(...
%     'SampleRate',           Fs_if, ...    
%     ...             % careful incase you use a higher up conversion
%     'NormalizePathGains',   true, ...
%     'DirectPathInitialPhase',0,...
%     'MaximumDopplerShift',  fd,...
%     'DopplerSpectrum',      doppler_spectrum,...
%     'RandomStream',         'mt19937ar with seed', ...
%     'Seed',                 73, ...
%     'PathGainsOutputPort',  false, ...
%     'KFactor',              calculateKFactorrandom_2(area), ...
%     'DirectPathDopplerShift',fd*rand, ...
%     'PathDelays',           PathDelays, ...
%     'AveragePathGains',     AveragePathGains, ...
%     'Visualization',        'Impulse and frequency responses', ...
%     'ChannelFiltering',false);  %%%%%% This property must be adjusted when
%                                 %%%%%% the program is used to be true


%% Visualization

ricianchan_1();
% ricianchan_2();

