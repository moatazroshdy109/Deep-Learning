function [x, Fs_bb] = loadAudioSegment(voice_file, num_samp, initial_sample)
    % Load an audio segment from the specified file
    % Parameters:
    % - voice_file: Path to the audio file
    % - num_samp: Number of samples to extract
    % - initial_sample: Starting sample index

    % Read the audio file
    [x, Fs_bb] = audioread(voice_file);

    % Extract the specified number of samples starting from initial_sample
    x = x(initial_sample:(initial_sample + num_samp - 1), 1);
end
