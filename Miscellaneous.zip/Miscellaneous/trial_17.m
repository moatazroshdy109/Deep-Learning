clear variables
close all

velocity = (0:5:60) * (1000/3600);
Fc = (30:5:3000) * 1e6;

fd = zeros(length(Fc), length(velocity));
T_c = zeros(length(Fc), length(velocity));

for i = 1:length(Fc)
    for j = 1:length(velocity)
        wavelength = 3e8 / Fc(i);
        fd(i, j) = velocity(j) / wavelength;
        T_c(i, j) = 1/fd(i, j); 
    end
end

% fd is the matrix containing Doppler frequency shifts
% Fc,and velocity are the vectors defining carrier frequencies 
% and velocities

figure;
surf(velocity, Fc / 1e6, fd);
xlabel('Velocity (m/s)');
ylabel('Carrier Frequency (MHz)');
zlabel('Doppler Frequency Shift (Hz)');
title('Doppler Frequency Shift vs Velocity and Carrier Frequency');

figure;
surf(velocity, Fc / 1e6, T_c);
xlabel('Velocity (m/s)');
ylabel('Carrier Frequency (MHz)');
zlabel('Doppler Frequency Shift (Hz)');
title('Doppler Frequency Shift vs Velocity and Carrier Frequency');